# English Lab B2–C1 — compilação Android e funcionalidades

Projeto nativo Java + Android WebView, com banco de 90.000 exercícios offline. Instruções atualizadas em `README.md` e `INSTRUCOES-PARA-CODEX.md` na raiz. A estrutura de dados fica em `app/src/main/assets/content/` (nove arquivos JSON de 10.000 registros por seção); a interface é `app/src/main/assets/app.js` e `styles.css`. O histórico fica na base SQLite definida em `StudyStore.java`.

O Gradle gera um APK de depuração com `gradle :app:assembleDebug`. A atualização sobre outro APK exige assinatura compatível; não existe aqui nenhuma chave de assinatura privada anterior. Execute os três testes locais antes de compilar e confirme o comportamento num Android ou emulador.

As 89.910 atividades compostas por regras ainda necessitam de revisão editorial linguística individual para garantir a naturalidade e evitar ambiguidades. O teste automatizado comprova formato, respostas estruturadas, IDs e enunciados não idênticos, não qualidade pedagógica absoluta.
