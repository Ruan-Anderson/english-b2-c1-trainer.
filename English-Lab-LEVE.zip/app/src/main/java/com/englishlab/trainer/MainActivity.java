package com.englishlab.trainer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int EXPORT_BACKUP = 201, IMPORT_BACKUP = 202;
    private WebView web;
    private StudyStore store;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(8,21,28));
        window.setNavigationBarColor(Color.rgb(8,21,28));
        store = new StudyStore(this);
        String legacy=getSharedPreferences("englishlab",Context.MODE_PRIVATE).getString("studyData", "");
        if(legacy!=null&&!legacy.isEmpty())store.migrateLegacy(legacy);
        tts = new TextToSpeech(this,status -> {if(status==TextToSpeech.SUCCESS&&tts!=null)ttsReady=tts.setLanguage(Locale.US)>=0;});
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(8,21,28));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.addJavascriptInterface(new NativeBridge(),"Native");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){
                Uri uri=req.getUrl();return !"file".equalsIgnoreCase(uri.getScheme())||!uri.toString().startsWith("file:///android_asset/");
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private final class NativeBridge {
        @JavascriptInterface public String getOverview(String month,String day){return store.overview(month,day);}
        @JavascriptInterface public String getSectionState(String section,long sessionStart){return store.getSectionState(section,sessionStart);}
        @JavascriptInterface public boolean recordAttempt(String json){return store.addAttempt(json);}
        @JavascriptInterface public void recordTime(String day,String section,double seconds){store.addStudyTime(day,section,seconds);}
        @JavascriptInterface public void setGoal(int minutes){store.setGoal(minutes);}
        @JavascriptInterface public void migrateLocal(String json){store.migrateLegacy(json);}
        @JavascriptInterface public String loadSection(String section){
            if(!section.matches("[a-z]+"))return "[]";
            try(InputStream in=getAssets().open("content/"+section+".json")){
                ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] bytes=new byte[8192];int n;
                while((n=in.read(bytes))!=-1)out.write(bytes,0,n);
                return out.toString("UTF-8");
            }catch(Exception ignored){return "[]";}
        }
        @JavascriptInterface public void say(String text){runOnUiThread(()->{if(ttsReady&&tts!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"english-lab-utterance");});}
        @JavascriptInterface public void shareReport(String text){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"English Lab — Relatório");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Compartilhar relatório"));});}
        @JavascriptInterface public void exportPdf(){runOnUiThread(()->{PrintManager manager=(PrintManager)getSystemService(Context.PRINT_SERVICE);if(manager!=null)manager.print("EnglishLab-Relatorio",web.createPrintDocumentAdapter("English Lab Relatório"),new PrintAttributes.Builder().build());});}
        @JavascriptInterface public void exportBackup(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"englishlab-backup-"+new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date())+".json");startActivityForResult(i,EXPORT_BACKUP);});}
        @JavascriptInterface public void importBackup(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,IMPORT_BACKUP);});}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try {
            if(request==EXPORT_BACKUP){
                try(OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null)throw new IllegalStateException("No output stream");
                    out.write(store.exportBackup().getBytes(StandardCharsets.UTF_8));
                }
                feedback("Backup salvo com sucesso.");
            }else if(request==IMPORT_BACKUP){
                byte[] bytes;try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new IllegalStateException("No input stream");
                    ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
                    while((n=in.read(buffer))!=-1){if(out.size()+n>12_000_000)throw new IllegalStateException("Backup muito grande");out.write(buffer,0,n);}
                    bytes=out.toByteArray();
                }
                if(store.importBackup(new String(bytes,StandardCharsets.UTF_8))){web.reload();feedback("Backup restaurado.");}
                else feedback("Backup inválido ou incompatível.");
            }
        }catch(Exception e){feedback("Não foi possível concluir a operação.");}
    }
    private void feedback(String message){
        if(web!=null)web.evaluateJavascript("window.studyNotice && window.studyNotice("+org.json.JSONObject.quote(message)+")",null);
    }
    @Override protected void onPause(){if(web!=null)web.evaluateJavascript("window.studyPause && window.studyPause()",null);super.onPause();}
    @Override protected void onResume(){super.onResume();if(web!=null)web.evaluateJavascript("window.studyResume && window.studyResume()",null);}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}if(web!=null){web.destroy();web=null;}if(store!=null)store.close();super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.studyBack && window.studyBack()",null);else super.onBackPressed();}
}
