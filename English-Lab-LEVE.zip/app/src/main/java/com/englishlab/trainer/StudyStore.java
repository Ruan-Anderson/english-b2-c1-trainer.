package com.englishlab.trainer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Indexed, transactional progress store. Exercise content stays in versioned offline assets. */
public final class StudyStore extends SQLiteOpenHelper {
    private static final String NAME = "englishlab-progress.db";
    private static final int VERSION = 2;
    private static final String[] SECTIONS = {"modals", "patterns", "conditionals", "prepositions", "get", "build", "perfect", "order", "phrasals"};

    StudyStore(Context context) { super(context, NAME, null, VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE attempts (id INTEGER PRIMARY KEY AUTOINCREMENT, exercise_id TEXT NOT NULL, section TEXT NOT NULL, day TEXT NOT NULL, occurred_at INTEGER NOT NULL, correct INTEGER NOT NULL, first_try INTEGER NOT NULL, hint INTEGER NOT NULL, translation INTEGER NOT NULL, attempt_number INTEGER NOT NULL, is_final INTEGER NOT NULL, is_review INTEGER NOT NULL, level TEXT NOT NULL DEFAULT 'unknown')");
        db.execSQL("CREATE INDEX attempts_exercise_idx ON attempts(exercise_id)");
        db.execSQL("CREATE INDEX attempts_section_idx ON attempts(section)");
        db.execSQL("CREATE INDEX attempts_day_idx ON attempts(day)");
        db.execSQL("CREATE TABLE completions (exercise_id TEXT PRIMARY KEY, section TEXT NOT NULL, finished_at INTEGER NOT NULL, day TEXT NOT NULL, first_try INTEGER NOT NULL, level TEXT NOT NULL DEFAULT 'unknown')");
        db.execSQL("CREATE INDEX completions_section_idx ON completions(section)");
        db.execSQL("CREATE INDEX completions_day_idx ON completions(day)");
        db.execSQL("CREATE TABLE reviews (exercise_id TEXT PRIMARY KEY, section TEXT NOT NULL, pending INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX reviews_section_idx ON reviews(section,pending,updated_at)");
        db.execSQL("CREATE TABLE study_time (day TEXT NOT NULL, section TEXT NOT NULL, seconds REAL NOT NULL, PRIMARY KEY(day,section))");
        db.execSQL("CREATE INDEX study_time_day_idx ON study_time(day)");
        db.execSQL("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int old, int next) {
        // Additive schema migrations only. Never drop a user-progress table.
        if (old < 2) {
            db.execSQL("CREATE INDEX IF NOT EXISTS completions_day_idx ON completions(day)");
            db.execSQL("CREATE INDEX IF NOT EXISTS attempts_day_idx ON attempts(day)");
            db.execSQL("ALTER TABLE completions ADD COLUMN level TEXT NOT NULL DEFAULT 'unknown'");
            db.execSQL("ALTER TABLE attempts ADD COLUMN level TEXT NOT NULL DEFAULT 'unknown'");
        }
    }
    private static boolean validSection(String s) {
        for (String key : SECTIONS) if (key.equals(s)) return true;
        return false;
    }
    private static String dayOf(long ts) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(ts));
    }
    private static String previousMonth(String month) {
        try { int year = Integer.parseInt(month.substring(0,4)), m = Integer.parseInt(month.substring(5,7));
            Calendar cal=Calendar.getInstance(); cal.clear(); cal.set(year,m-2,1);
            return new SimpleDateFormat("yyyy-MM",Locale.US).format(cal.getTime());
        } catch(Exception ignored) { return "0000-00"; }
    }
    private static long count(SQLiteDatabase db,String sql,String... args) {
        try(Cursor cursor=db.rawQuery(sql,args)) { return cursor.moveToFirst()?cursor.getLong(0):0L; }
    }
    private static double sum(SQLiteDatabase db,String sql,String... args) {
        try(Cursor cursor=db.rawQuery(sql,args)) { return cursor.moveToFirst()?cursor.getDouble(0):0; }
    }
    private static int flag(boolean v) {return v?1:0;}
    private static JSONObject obj(String key,Object value) throws JSONException {return new JSONObject().put(key,value);}
    private String setting(SQLiteDatabase db,String key,String fallback) {
        try(Cursor c=db.rawQuery("SELECT value FROM settings WHERE key=?",new String[]{key})) {return c.moveToFirst()?c.getString(0):fallback;}
    }
    private void setSetting(SQLiteDatabase db,String key,String value) {
        ContentValues cv=new ContentValues();cv.put("key",key);cv.put("value",value);db.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public synchronized void setGoal(int minutes) {
        if(minutes<1||minutes>720)return;
        SQLiteDatabase db=getWritableDatabase();setSetting(db,"goal",String.valueOf(minutes));
    }
    /** Attempts are immutable rows; completion has exactly one row per exercise ID. */
    private void addAttemptInternal(SQLiteDatabase db,JSONObject item) throws JSONException {
        String id=item.optString("exerciseId", ""), section=item.optString("section", "");
        if(!id.matches("[a-zA-Z0-9_-]{1,80}")||!validSection(section))throw new JSONException("Invalid exercise ID or section");
        long ts=item.optLong("timestamp",System.currentTimeMillis());
        String day=item.optString("day",dayOf(ts));
        if(!day.matches("\\d{4}-\\d{2}-\\d{2}")) day=dayOf(ts);
        boolean correct=item.optBoolean("correct",false),first=item.optBoolean("firstTry",false),isFinal=item.optBoolean("final",false),review=item.optBoolean("review",false);
        ContentValues cv=new ContentValues();cv.put("exercise_id",id);cv.put("section",section);cv.put("day",day);cv.put("occurred_at",ts);cv.put("correct",flag(correct));cv.put("first_try",flag(first));cv.put("hint",flag(item.optBoolean("hint",false)));cv.put("translation",flag(item.optBoolean("translation",false)));cv.put("attempt_number",Math.max(1,item.optInt("attemptNumber",1)));cv.put("is_final",flag(isFinal));cv.put("is_review",flag(review));cv.put("level",item.optString("level","unknown"));
        db.insertOrThrow("attempts",null,cv);
        if(isFinal) {
            boolean genuineFirst = correct && first && !review &&
                count(db,"SELECT COUNT(*) FROM attempts WHERE exercise_id=? AND is_review=0",id)==1;
            ContentValues finished=new ContentValues();finished.put("exercise_id",id);finished.put("section",section);finished.put("day",day);finished.put("finished_at",ts);finished.put("first_try",flag(genuineFirst));finished.put("level",item.optString("level","unknown"));
            db.insertWithOnConflict("completions",null,finished,SQLiteDatabase.CONFLICT_IGNORE);
        }
        if(!correct) {
            ContentValues pending=new ContentValues();pending.put("exercise_id",id);pending.put("section",section);pending.put("pending",1);pending.put("updated_at",ts);
            db.insertWithOnConflict("reviews",null,pending,SQLiteDatabase.CONFLICT_REPLACE);
        } else if(first && (review || count(db,"SELECT COUNT(*) FROM attempts WHERE exercise_id=? AND is_review=0",id)==1)) {
            ContentValues cleared=new ContentValues();cleared.put("exercise_id",id);cleared.put("section",section);cleared.put("pending",0);cleared.put("updated_at",ts);
            db.insertWithOnConflict("reviews",null,cleared,SQLiteDatabase.CONFLICT_REPLACE);
        }
    }
    public synchronized boolean addAttempt(String json) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {addAttemptInternal(db,new JSONObject(json));db.setTransactionSuccessful();return true;}
        catch(Exception ignored) {return false;}
        finally {db.endTransaction();}
    }
    public synchronized void addStudyTime(String day,String section,double seconds) {
        if(!validSection(section)||day==null||!day.matches("\\d{4}-\\d{2}-\\d{2}")||seconds<=0||seconds>600)return;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            ContentValues inc=new ContentValues();inc.put("seconds",seconds+sum(db,"SELECT COALESCE(SUM(seconds),0) FROM study_time WHERE day=? AND section=?",day,section));
            int changed=db.update("study_time",inc,"day=? AND section=?",new String[]{day,section});
            if(changed==0){inc.put("day",day);inc.put("section",section);db.insertOrThrow("study_time",null,inc);}
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public synchronized String getSectionState(String section,long startAt) {
        if(!validSection(section))return "{\"completed\":[],\"pending\":[]}";
        SQLiteDatabase db=getReadableDatabase();JSONObject o=new JSONObject();JSONArray completed=new JSONArray(),pending=new JSONArray();
        try {
            try(Cursor c=db.rawQuery("SELECT exercise_id FROM completions WHERE section=?",new String[]{section}))while(c.moveToNext())completed.put(c.getString(0));
            try(Cursor c=db.rawQuery("SELECT exercise_id FROM reviews WHERE section=? AND pending=1 AND updated_at < ?",new String[]{section,String.valueOf(startAt)}))while(c.moveToNext())pending.put(c.getString(0));
            o.put("completed",completed);o.put("pending",pending);
        }catch(Exception ignored){}
        return o.toString();
    }
    private JSONObject summarize(SQLiteDatabase db,String month) throws JSONException {
        JSONObject obj=new JSONObject();
        String like=month+"%";
        long newCount=count(db,"SELECT COUNT(*) FROM completions WHERE day LIKE ?",like);
        long firstCount=count(db,"SELECT COUNT(*) FROM completions WHERE day LIKE ? AND first_try=1",like);
        obj.put("newCount",newCount);obj.put("firstCount",firstCount);obj.put("c1Count",count(db,"SELECT COUNT(*) FROM completions WHERE day LIKE ? AND level='C1'",like));obj.put("c1First",count(db,"SELECT COUNT(*) FROM completions WHERE day LIKE ? AND level='C1' AND first_try=1",like));obj.put("accuracy",newCount==0?0:Math.round(100d*firstCount/newCount));
        obj.put("attempts",count(db,"SELECT COUNT(*) FROM attempts WHERE day LIKE ?",like));
        obj.put("reviewAttempts",count(db,"SELECT COUNT(*) FROM attempts WHERE day LIKE ? AND is_review=1",like));
        obj.put("hints",count(db,"SELECT COUNT(*) FROM attempts WHERE day LIKE ? AND hint=1",like));
        obj.put("seconds",sum(db,"SELECT COALESCE(SUM(seconds),0) FROM study_time WHERE day LIKE ?",like));
        JSONObject perSection=new JSONObject();
        for(String section:SECTIONS) {
            JSONObject r=new JSONObject();
            r.put("newCount",count(db,"SELECT COUNT(*) FROM completions WHERE day LIKE ? AND section=?",like,section));
            r.put("firstCount",count(db,"SELECT COUNT(*) FROM completions WHERE day LIKE ? AND section=? AND first_try=1",like,section));
            r.put("c1Count",count(db,"SELECT COUNT(*) FROM completions WHERE day LIKE ? AND section=? AND level='C1'",like,section));
            r.put("attempts",count(db,"SELECT COUNT(*) FROM attempts WHERE day LIKE ? AND section=?",like,section));
            r.put("seconds",sum(db,"SELECT COALESCE(SUM(seconds),0) FROM study_time WHERE day LIKE ? AND section=?",like,section));
            perSection.put(section,r);
        }
        obj.put("sections",perSection);return obj;
    }
    public synchronized String overview(String month,String day) {
        SQLiteDatabase db=getReadableDatabase();JSONObject o=new JSONObject();
        if(month==null||!month.matches("\\d{4}-\\d{2}"))month=dayOf(System.currentTimeMillis()).substring(0,7);
        if(day==null||!day.matches("\\d{4}-\\d{2}-\\d{2}"))day=dayOf(System.currentTimeMillis());
        try {
            o.put("goal",Integer.parseInt(setting(db,"goal","150")));
            o.put("completedOverall",count(db,"SELECT COUNT(*) FROM completions"));
            o.put("attemptsOverall",count(db,"SELECT COUNT(*) FROM attempts"));
            JSONObject total=new JSONObject(),pending=new JSONObject();
            for(String section:SECTIONS) {
                total.put(section,count(db,"SELECT COUNT(*) FROM completions WHERE section=?",section));
                pending.put(section,count(db,"SELECT COUNT(*) FROM reviews WHERE section=? AND pending=1",section));
            }
            o.put("completedBySection",total);o.put("pendingBySection",pending);
            o.put("selected",summarize(db,month));o.put("previous",summarize(db,previousMonth(month)));
            JSONObject dayDetails=new JSONObject();
            dayDetails.put("seconds",sum(db,"SELECT COALESCE(SUM(seconds),0) FROM study_time WHERE day=?",day));
            dayDetails.put("newCount",count(db,"SELECT COUNT(*) FROM completions WHERE day=?",day));
            dayDetails.put("firstCount",count(db,"SELECT COUNT(*) FROM completions WHERE day=? AND first_try=1",day));
            dayDetails.put("attempts",count(db,"SELECT COUNT(*) FROM attempts WHERE day=?",day));
            JSONObject daySections=new JSONObject();for(String section:SECTIONS)daySections.put(section,sum(db,"SELECT COALESCE(SUM(seconds),0) FROM study_time WHERE day=? AND section=?",day,section));
            dayDetails.put("sections",daySections);o.put("day",dayDetails);
            JSONArray calendar=new JSONArray();
            try(Cursor c=db.rawQuery("SELECT day, SUM(seconds) FROM study_time WHERE day LIKE ? GROUP BY day",new String[]{month+"%"})){
                while(c.moveToNext())calendar.put(new JSONObject().put("day",c.getString(0)).put("seconds",c.getDouble(1)));
            }
            o.put("calendar",calendar);
        }catch(Exception ignored){}
        return o.toString();
    }
    /** Legacy JSON from the v1 SharedPreferences or its localStorage fallback. */
    public synchronized boolean migrateLegacy(String json) {
        SQLiteDatabase db=getWritableDatabase();
        if("1".equals(setting(db,"legacy_imported","0")))return false;
        if(json==null||json.trim().isEmpty())return false;
        db.beginTransaction();
        try {
            JSONObject old=new JSONObject(json);
            JSONArray answers=old.optJSONArray("answers");if(answers!=null)for(int i=0;i<answers.length();i++){
                JSONObject a=answers.optJSONObject(i);if(a==null)continue;
                String section=a.optString("category",""),id=a.optString("id","");if(!validSection(section)||id.isEmpty())continue;
                long at=a.optLong("time",a.optLong("at",System.currentTimeMillis()));
                JSONObject normalized=new JSONObject().put("exerciseId",id).put("section",section).put("day",a.optString("date",dayOf(at)))
                    .put("timestamp",at).put("correct",a.optBoolean("correct",false)).put("firstTry",a.optBoolean("correct",false)&&a.optInt("tries",a.optInt("attempts",1))==1)
                    .put("hint",a.optBoolean("hint",a.optBoolean("hints",false))).put("translation",a.optBoolean("translation",a.optBoolean("translated",false)))
                    .put("attemptNumber",a.optInt("tries",a.optInt("attempts",1))).put("final",true).put("review",false);
                addAttemptInternal(db,normalized);
            }
            JSONObject seconds=old.optJSONObject("bySection");
            if(seconds!=null){JSONArray names=seconds.names();if(names!=null)for(int i=0;i<names.length();i++){
                String k=names.getString(i);String[] split=k.split("\\|",2);
                if(split.length==2&&split[0].matches("\\d{4}-\\d{2}-\\d{2}")&&validSection(split[1])){
                    double s=seconds.optDouble(k,0);if(s>0)db.execSQL("INSERT OR IGNORE INTO study_time(day,section,seconds) VALUES (?,?,?)",new Object[]{split[0],split[1],s});
                }
            }}
            // Older builds may only contain a total-by-day counter.
            JSONObject total=old.optJSONObject("seconds");
            if(total!=null){JSONArray names=total.names();if(names!=null)for(int i=0;i<names.length();i++){
                String day=names.getString(i);if(day.matches("\\d{4}-\\d{2}-\\d{2}")){
                    double s=total.optDouble(day,0),assigned=sum(db,"SELECT COALESCE(SUM(seconds),0) FROM study_time WHERE day=?",day);
                    if(s>assigned)db.execSQL("INSERT OR IGNORE INTO study_time(day,section,seconds) VALUES (?,?,?)",new Object[]{day,"build",s-assigned});
                }
            }}
            int goal=old.optInt("goal",old.optInt("target",150));if(goal>0&&goal<=720)setSetting(db,"goal",String.valueOf(goal));
            setSetting(db,"legacy_imported","1");db.setTransactionSuccessful();return true;
        }catch(Exception ignored){return false;}
        finally{db.endTransaction();}
    }
    public synchronized String exportBackup() {
        JSONObject root=new JSONObject();SQLiteDatabase db=getReadableDatabase();
        try {
            root.put("format","englishlab-sqlite-backup-v2");root.put("createdAt",System.currentTimeMillis());root.put("goal",Integer.parseInt(setting(db,"goal","150")));
            JSONArray attempts=new JSONArray();
            try(Cursor c=db.rawQuery("SELECT exercise_id,section,day,occurred_at,correct,first_try,hint,translation,attempt_number,is_final,is_review,level FROM attempts ORDER BY id",null)){
                while(c.moveToNext())attempts.put(new JSONObject().put("exerciseId",c.getString(0)).put("section",c.getString(1)).put("day",c.getString(2)).put("timestamp",c.getLong(3)).put("correct",c.getInt(4)==1).put("firstTry",c.getInt(5)==1).put("hint",c.getInt(6)==1).put("translation",c.getInt(7)==1).put("attemptNumber",c.getInt(8)).put("final",c.getInt(9)==1).put("review",c.getInt(10)==1).put("level",c.getString(11)));
            }root.put("attempts",attempts);
            JSONArray times=new JSONArray();
            try(Cursor c=db.rawQuery("SELECT day,section,seconds FROM study_time",null)){while(c.moveToNext())times.put(new JSONObject().put("day",c.getString(0)).put("section",c.getString(1)).put("seconds",c.getDouble(2)));}
            root.put("times",times);
            JSONArray reviews=new JSONArray();
            try(Cursor c=db.rawQuery("SELECT exercise_id,section,pending,updated_at FROM reviews",null)){while(c.moveToNext())reviews.put(new JSONObject().put("exerciseId",c.getString(0)).put("section",c.getString(1)).put("pending",c.getInt(2)==1).put("updatedAt",c.getLong(3)));}
            root.put("reviews",reviews);
        }catch(Exception ignored){}
        return root.toString();
    }
    /** Import intentionally REPLACES existing data; caller requests user confirmation. */
    public synchronized boolean importBackup(String json) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            JSONObject root=new JSONObject(json);if(!"englishlab-sqlite-backup-v2".equals(root.optString("format")))return false;
            JSONArray attempts=root.getJSONArray("attempts"),times=root.getJSONArray("times"),reviews=root.optJSONArray("reviews");
            db.delete("attempts",null,null);db.delete("completions",null,null);db.delete("reviews",null,null);db.delete("study_time",null,null);
            for(int i=0;i<attempts.length();i++)addAttemptInternal(db,attempts.getJSONObject(i));
            for(int i=0;i<times.length();i++){JSONObject t=times.getJSONObject(i);String day=t.getString("day"),section=t.getString("section");if(!validSection(section)||!day.matches("\\d{4}-\\d{2}-\\d{2}"))continue;
                db.execSQL("INSERT OR REPLACE INTO study_time(day,section,seconds) VALUES (?,?,?)",new Object[]{day,section,Math.max(0,t.optDouble("seconds",0))});}
            if(reviews!=null)for(int i=0;i<reviews.length();i++){JSONObject r=reviews.getJSONObject(i);if(!validSection(r.optString("section")))continue;
                ContentValues cv=new ContentValues();cv.put("exercise_id",r.getString("exerciseId"));cv.put("section",r.getString("section"));cv.put("pending",flag(r.optBoolean("pending")));cv.put("updated_at",r.optLong("updatedAt"));db.insertWithOnConflict("reviews",null,cv,SQLiteDatabase.CONFLICT_REPLACE);}
            int goal=root.optInt("goal",150);setSetting(db,"goal",String.valueOf(goal>0&&goal<=720?goal:150));setSetting(db,"legacy_imported","1");db.setTransactionSuccessful();return true;
        }catch(Exception ignored){return false;}
        finally{db.endTransaction();}
    }
}
