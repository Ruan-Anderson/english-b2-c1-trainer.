(() => {
'use strict';
const $ = id => document.getElementById(id);
const SECTIONS = [
 ['modals','Modal Verbs','Conselhos, deduções e possibilidades','quiz'],
 ['patterns','Verb Patterns','Verb + -ing, to-infinitive e combinações','quiz'],
 ['conditionals','Conditionals','Fatos, hipóteses e consequências','quiz'],
 ['prepositions','Prepositions','Preposições e expressões naturais','quiz'],
 ['get','Get / Got / Getting / Gotten','Sentidos e formas de get','quiz'],
 ['build','Build the Sentence','Frases completas e espontâneas','builder'],
 ['perfect','Present Perfect','Simple, Continuous e advérbios','builder'],
 ['order','Word Order','Perguntas, auxiliares e posições','builder'],
 ['phrasals','Phrasal Verbs','Expressões e partículas verbais','builder']
];
const DATA = window.EXERCISE_DATA = window.EXERCISE_DATA || {};
const MANIFEST = window.EXERCISE_MANIFEST || {validatedTotal:0,targetTotal:90000,sections:{}};
const pad = n=>String(n).padStart(2,'0');
const dateKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const monthKey = (d = new Date())=>dateKey(d).slice(0,7);
const esc = s=>String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mins = s=>{const m=Math.floor(Math.max(0,s)/60);return m>=60?`${Math.floor(m/60)}h ${pad(m%60)}min`:`${m} min`;};
const native=window.Native && typeof window.Native.getOverview==='function';
const DICTIONARY={i:'Eu',we:'Nós',you:'Você',they:'Eles / elas',he:'Ele',she:'Ela',it:'Isso',had:'Tinha / havia',have:'Ter ou auxiliar',has:'Tem / auxiliar',been:'Particípio de be',is:'É / está',was:'Era / estava',were:'Eram / estavam',are:'São / estão',the:'O / a',a:'Um / uma',an:'Um / uma',not:'Não',can:'Conseguir / poder',could:'Poderia',would:'Auxiliar de hipótese',should:'Deveria',must:'Deve / necessidade',might:'Talvez / poderia',will:'Auxiliar de futuro',this:'Este / isso',that:'Aquele / que',of:'De',on:'Em / sobre',to:'Para / infinitivo',at:'Em',in:'Em',with:'Com',for:'Por / para',and:'E',but:'Mas',or:'Ou',as:'Como / enquanto',while:'Enquanto',before:'Antes',after:'Depois',already:'Já',yet:'Ainda / já em perguntas',ever:'Alguma vez',never:'Nunca',just:'Acabou de / apenas',still:'Ainda',since:'Desde',until:'Até',my:'Meu / minha',our:'Nosso / nossa',his:'Dele',her:'Dela / ela',them:'Eles / elas (objeto)',your:'Seu / sua',their:'Deles / delas',time:'Tempo',get:'Obter / ficar (conforme contexto)',got:'Passado de get',getting:'Forma -ing de get',gotten:'Particípio de get (americano)'};
function blankStats(){return {newCount:0,firstCount:0,accuracy:0,seconds:0,attempts:0,c1Count:0,c1First:0,sections:{}};}
function fallback() {
 let db;try{db=JSON.parse(localStorage.getItem('englishLabV2')||'null');}catch{}
 if(!db){
   let old={};try{old=JSON.parse(localStorage.getItem('englishLabData')||'{}');}catch{}
   const attempts=(old.answers||[]).map(a=>({exerciseId:a.id,section:a.category,day:a.date||dateKey(),timestamp:a.time||a.at||Date.now(),correct:!!a.correct,firstTry:!!a.correct&&(a.tries||a.attempts||1)===1,hint:!!a.hint,translation:!!a.translation,attemptNumber:a.tries||a.attempts||1,final:true,review:false,level:'unknown'}));
   db={attempts,times:old.bySection||{},goal:old.goal||150};
 }
 const save=()=>{try{localStorage.setItem('englishLabV2',JSON.stringify(db));}catch{}};
 const completions=()=>{const map=new Map(),first=new Map();for(const a of db.attempts||[]){if(!first.has(a.exerciseId)&&!a.review)first.set(a.exerciseId,a);if(a.final&&!map.has(a.exerciseId))map.set(a.exerciseId,{...a,firstTry:!!(first.get(a.exerciseId)?.correct)});}return [...map.values()];};
 const pending=()=>{const map=new Map();for(const a of db.attempts||[]){if(!a.correct)map.set(a.exerciseId,{section:a.section,pending:true,time:a.timestamp});else if(a.firstTry)map.set(a.exerciseId,{section:a.section,pending:false,time:a.timestamp});}return map;};
 const summary=month=>{
   const c=completions().filter(a=>a.day.startsWith(month)),rows=(db.attempts||[]).filter(a=>a.day.startsWith(month));
   const times=Object.entries(db.times).filter(([k])=>k.startsWith(month));
   const sections={};for(const [key] of SECTIONS){const own=c.filter(a=>a.section===key);sections[key]={newCount:own.length,firstCount:own.filter(a=>a.firstTry&&a.correct).length,c1Count:own.filter(a=>a.level==='C1').length,attempts:rows.filter(a=>a.section===key).length,seconds:times.filter(([k])=>k.endsWith('|'+key)).reduce((v,[,s])=>v+s,0)};}
   const firstCount=c.filter(a=>a.firstTry&&a.correct).length;
   return {newCount:c.length,firstCount,accuracy:c.length?Math.round(firstCount/c.length*100):0,seconds:times.reduce((v,[,s])=>v+s,0),attempts:rows.length,c1Count:c.filter(a=>a.level==='C1').length,c1First:c.filter(a=>a.level==='C1'&&a.firstTry&&a.correct).length,hints:rows.filter(a=>a.hint).length,reviewAttempts:rows.filter(a=>a.review).length,sections};
 };
 return {
   sectionState(section,cutoff){return {completed:completions().filter(a=>a.section===section).map(a=>a.exerciseId),pending:[...pending()].filter(([id,r])=>r.section===section&&r.pending&&r.time<cutoff).map(([id])=>id)};},
   attempt(a){db.attempts.push(a);save();return true;},
   time(day,sec,s){const k=day+'|'+sec;db.times[k]=(db.times[k]||0)+s;save();},
   goal(n){db.goal=n;save();},
   overview(month,day){
     const c=completions(),r=pending(),total={},pendingBySection={};for(const [key] of SECTIONS){total[key]=c.filter(a=>a.section===key).length;pendingBySection[key]=[...r].filter(([,v])=>v.section===key&&v.pending).length;}
     const [y,m]=month.split('-').map(Number),prev=new Date(y,m-2,1),pm=monthKey(prev);
     const dayCompleted=c.filter(a=>a.day===day),dayTimes=Object.entries(db.times).filter(([k])=>k.startsWith(day+'|'));
     const sections={};for(const [key] of SECTIONS)sections[key]=dayTimes.filter(([k])=>k.endsWith('|'+key)).reduce((v,[,s])=>v+s,0);
     const uniqueDates=[...new Set(Object.keys(db.times).map(k=>k.split('|')[0]))].filter(d=>d.startsWith(month));
     return {goal:db.goal||150,completedOverall:c.length,attemptsOverall:db.attempts.length,completedBySection:total,pendingBySection,selected:summary(month),previous:summary(pm),day:{seconds:dayTimes.reduce((v,[,s])=>v+s,0),newCount:dayCompleted.length,firstCount:dayCompleted.filter(a=>a.correct&&a.firstTry).length,attempts:db.attempts.filter(a=>a.day===day).length,sections},calendar:uniqueDates.map(d=>({day:d,seconds:Object.entries(db.times).filter(([k])=>k.startsWith(d+'|')).reduce((v,[,s])=>v+s,0)}))};
   }
 };
}
const browserStore=native?null:fallback();
const state={screen:'home',catalog:'builder',section:'build',lesson:null,mode:'normal',due:[],reviewDue:[],queueIndex:0,picked:[],choice:null,result:null,tries:0,hint:false,translation:false,word:null,lookup:false,month:monthKey(),date:dateKey(),sessionStart:Date.now(),latest:null,notice:'',secondsPending:{},liveSeconds:0,loading:false};
function notify(msg){state.notice=msg;render();}
function overview(){
 try{return native?JSON.parse(window.Native.getOverview(state.month,state.date)):browserStore.overview(state.month,state.date);}catch{return {goal:150,completedOverall:0,attemptsOverall:0,completedBySection:{},pendingBySection:{},selected:blankStats(),previous:blankStats(),day:{seconds:0,newCount:0,firstCount:0,attempts:0,sections:{}},calendar:[]};}
}
function sectionState(section){try{return native?JSON.parse(window.Native.getSectionState(section,state.sessionStart)):browserStore.sectionState(section,state.sessionStart);}catch{return {completed:[],pending:[]};}}
function sendAttempt(correct,final,number){
 if(!state.lesson)return false;
 const e=state.lesson;
 const attempt={exerciseId:e.id,section:e.category,level:e.level,day:dateKey(),timestamp:Date.now(),correct:!!correct,firstTry:correct&&number===1,hint:state.hint,translation:state.translation,attemptNumber:number,final:!!final,review:state.mode==='review'};
 const saved=native?window.Native.recordAttempt(JSON.stringify(attempt)):browserStore.attempt(attempt);
 if(!saved){notify('Não foi possível salvar a tentativa. Tente novamente.');return false;}
 return true;
}
function flushTime(){const pending=state.secondsPending;state.secondsPending={};for(const [k,seconds] of Object.entries(pending)){const [date,section]=k.split('|');try{if(native)window.Native.recordTime(date,section,seconds);else browserStore.time(date,section,seconds);}catch{state.secondsPending[k]=(state.secondsPending[k]||0)+seconds;}}}
function chooseMonth(n){flushTime();const [year,month]=state.month.split('-').map(Number),d=new Date(year,month-1+n,1);state.month=monthKey(d);state.date=dateKey(d);render();}
function displayMonth(){return new Date(state.month+'-01T12:00:00').toLocaleDateString('pt-BR',{month:'long',year:'numeric'});}
function resetAnswer(){state.picked=[];state.choice=null;state.result=null;state.tries=0;state.hint=false;state.translation=false;state.word=null;state.lookup=false;lastActivity=Date.now();}
function shuffle(e){const arr=e.sentence.split(/\s+/).map((text,id)=>({text,id}));let seed=[...e.id].reduce((v,c)=>(v*33+c.charCodeAt(0))>>>0,123);for(let i=arr.length-1;i>0;i--){seed=(seed*1664525+1013904223)>>>0;const j=seed%(i+1);[arr[i],arr[j]]=[arr[j],arr[i]];}if(arr.every((x,i)=>x.id===i))arr.reverse();return arr;}
function tokens(){return shuffle(state.lesson);}
function meaning(text){const e=state.lesson,key=text.toLowerCase().replace(/^[^\p{L}]+|[^\p{L}]+$/gu,'');return (e.vocab&&e.vocab[key])||DICTIONARY[key]||(window.ENGLISH_GLOSSARY&&window.ENGLISH_GLOSSARY[key])||'O significado individual ainda não foi revisado. Consulte a tradução contextual da frase inteira.';}
function speech(){const e=state.lesson;if(!e)return;const text=e.choices?e.sentence.replace('___',e.choices[e.correct]):e.sentence;try{if(native)window.Native.say(text);else if(window.speechSynthesis){window.speechSynthesis.cancel();const s=new SpeechSynthesisUtterance(text);s.lang='en-US';s.rate=.9;window.speechSynthesis.speak(s);}}catch{}}
async function loadSection(key){
 if(DATA[key])return DATA[key];
 if(native){try{const loaded=JSON.parse(window.Native.loadSection(key));if(Array.isArray(loaded)&&loaded.every(e=>e.category===key)){DATA[key]=loaded;return loaded;}}catch{}throw Error('Não foi possível carregar a seção '+key);}
 return new Promise((resolve,reject)=>{
   const script=document.createElement('script');script.src='content/'+key+'.js';script.onload=()=>DATA[key]?resolve(DATA[key]):reject(Error('Seção vazia'));script.onerror=()=>reject(Error('Falha ao carregar seção'));document.head.appendChild(script);
 });
}
async function openLesson(key,mode='normal'){
 const section=SECTIONS.find(s=>s[0]===key);if(!section)return;
 state.loading=true;state.screen='exercise';state.section=key;state.catalog=section[3];state.mode=mode;render();
 try{
   const list=await loadSection(key),s=sectionState(key);
   const candidates=mode==='review'?list.filter(e=>s.pending.includes(e.id)):list.filter(e=>!s.completed.includes(e.id));
   state.due=candidates;state.queueIndex=0;state.lesson=candidates[0]||null;resetAnswer();state.screen=candidates.length?'exercise':'done';
 }catch(error){state.screen='error';state.notice=String(error.message||error);}
 state.loading=false;render();
}
async function next(){
 if(!state.lesson||!(state.result==='good'||state.result==='bad'&&state.lesson.choices||state.result==='reveal'))return;
 state.queueIndex++;
 if(state.queueIndex<state.due.length){state.lesson=state.due[state.queueIndex];resetAnswer();render();return;}
 if(state.mode==='review'){state.screen='done';state.lesson=null;render();return;}
 const idx=SECTIONS.findIndex(s=>s[0]===state.section);
 for(let i=idx+1;i<SECTIONS.length;i++){
   const candidate=SECTIONS[i][0];await loadSection(candidate);
   const done=sectionState(candidate).completed;
   if(DATA[candidate].some(x=>!done.includes(x.id))){await openLesson(candidate);return;}
 }
 state.lesson=null;state.screen='done';render();
}
function quizAnswer(choice){if(state.result!==null||!state.lesson)return;const e=state.lesson;const good=choice===e.correct;state.choice=choice;if(!sendAttempt(good,true,1))return;state.result=good?'good':'bad';state.translation=true;render();}
function chooseToken(id){if(!state.lesson||state.result==='good'||state.result==='reveal')return;const w=tokens().find(x=>x.id===id);if(!w)return;if(state.lookup){state.word=w.text;}else if(!state.picked.includes(id)){state.picked.push(id);state.result=null;}render();}
function removeToken(position){if(state.result==='good'||state.result==='reveal')return;const id=state.picked[position];const w=tokens().find(x=>x.id===id);if(state.lookup){state.word=w?.text||null;}else{state.picked.splice(position,1);state.result=null;}render();}
const normalized = word => word.replace(/[^\p{L}\p{N}']/gu,'').toLowerCase();
function checkBuilder(){if(!state.lesson||state.result==='good'||state.result==='reveal')return;const e=state.lesson,words=e.sentence.split(/\s+/),assembled=state.picked.map(i=>words[i]);
 if(assembled.length!==words.length)return;
 const exact=state.picked.every((id,i)=>id===i);
 const alt=(e.accepted||[]).some(s=>s.split(/\s+/).map(normalized).join(' ')===assembled.map(normalized).join(' '));
 const good=exact||alt,n=state.tries+1;
 if(!sendAttempt(good,good,n))return;
 state.tries=n;state.result=good?'good':'bad';if(good)state.translation=true;render();
}
function reveal(){if(!state.lesson||state.result==='good'||state.result==='reveal')return;if(!sendAttempt(false,true,state.tries+1))return;
 state.picked=state.lesson.sentence.split(/\s+/).map((_,i)=>i);state.result='reveal';state.translation=true;render();}
function catalog(type){state.catalog=type;state.screen='catalog';flushTime();render();}
function go(screen){flushTime();state.screen=screen;state.notice='';render();}
function header(){return `<header class="top"><button class="brand" onclick="Study.go('home')"><span class="logo">e.</span><span>english<span class="mint">lab</span><small>AMERICAN ENGLISH · B2–C1</small></span></button><span class="indicator"></span></header>`;}
function nav(){return `<nav class="bottom">${[['home','⌂','Início'],['quiz','▤','Quiz'],['builder','▦','Frases'],['progress','▦','Histórico'],['report','▥','Relatório']].map(([key,ico,label])=>{const active=state.screen===key||(state.screen==='catalog'||state.screen==='exercise')&&state.catalog===key;const click=key==='quiz'||key==='builder'?`Study.catalog('${key}')`:`Study.go('${key}')`;return `<button class="${active?'active':''}" onclick="${click}"><span class="symbol">${ico}</span>${label}</button>`;}).join('')}</nav>`;}
function alertHtml(){return state.notice?`<div class="appnotice">${esc(state.notice)} <button onclick="Study.dismiss()">×</button></div>`:'';}
function home(){const o=overview(),today=dateKey()===state.date?o.day.seconds:0,total=o.completedOverall;
 return `<section class="page"><div class="hero"><div class="tag">✧ SUA JORNADA DE FLUÊNCIA</div><h1>Think in English.<br><b>Speak with confidence.</b></h1><p>Construa frases naturalmente e acompanhe sua evolução em inglês americano B2–C1.</p><button class="button" onclick="Study.catalog('builder')">▶ Começar a praticar ›</button></div><div class="cards2"><div class="stat"><small>◷ TEMPO HOJE</small><strong>${mins(today)}</strong><p>Meta: ${mins(o.goal*60)}</p><div class="track"><i style="width:${Math.min(100,100*today/(o.goal*60))}%"></i></div></div><div class="stat"><small>◎ EXERCÍCIOS CONCLUÍDOS</small><strong>${total} / ${MANIFEST.validatedTotal}</strong><p>IDs distintos, sem duplicação</p><div class="track"><i style="width:${MANIFEST.validatedTotal?100*total/MANIFEST.validatedTotal:0}%"></i></div></div></div><div class="tag">ESCOLHA SEU TREINO</div><h2 class="sectiontitle">Seu próximo passo</h2><div class="cards2 modules"><button class="module" onclick="Study.catalog('builder')"><span class="moduleicon">▦</span><small>MÓDULO 01 · PRIORIDADE</small><strong>Formador de Frases</strong><p>Organize palavras e domine frases naturais.</p><span>4 seções →</span></button><button class="module" onclick="Study.catalog('quiz')"><span class="moduleicon">▤</span><small>MÓDULO 02</small><strong>Quiz de Gramática</strong><p>Responda com confiança e entenda cada estrutura.</p><span>5 seções →</span></button></div><button class="button block ghost" onclick="Study.go('review')">↻ Revisar dificuldades (${Object.values(o.pendingBySection||{}).reduce((a,b)=>a+b,0)} pendentes)</button><p class="notice">✓ ${MANIFEST.validatedTotal.toLocaleString('pt-BR')} exercícios disponíveis: ${(MANIFEST.originalCuratedTotal||90)} originalmente escritos e ${(MANIFEST.generatedRuleBasedTotal||89910).toLocaleString('pt-BR')} produzidos por composição gramatical. IDs, campos e duplicações exatas verificados automaticamente; revisão editorial integral pendente.</p></section>`;
}
function catalogView(){const o=overview();return `<section class="page"><button class="back" onclick="Study.go('home')">‹ Início</button><div class="tag">${state.catalog==='quiz'?'MÓDULO · QUIZ':'MÓDULO · FORMADOR DE FRASES'}</div><h1>${state.catalog==='quiz'?'Escolha uma habilidade':'Construa frases com confiança'}</h1><p class="intro">${state.catalog==='quiz'?'Três alternativas, uma dica e explicações claras.':'Organize as palavras e consulte o significado contextual.'}</p><div class="categories">${SECTIONS.filter(s=>s[3]===state.catalog).map((s,i)=>`<button class="category" onclick="Study.lesson('${s[0]}')"><span class="categorynum">${pad(i+1)}</span><span class="categorytxt"><strong>${esc(s[1])}</strong><small>${esc(s[2])}</small><em>${MANIFEST.sections[s[0]]||0} disponíveis · ${o.completedBySection[s[0]]||0} concluídos</em></span><span>›</span></button>`).join('')}</div></section>`;}
function reviewView(){const o=overview();return `<section class="page"><button class="back" onclick="Study.go('home')">‹ Início</button><div class="tag">REVISÃO ESPAÇADA · DIFICULDADES</div><h1>Revisar dificuldades</h1><p class="intro">Questões erradas ficam pendentes para a próxima sessão. Acertar de primeira na revisão remove a pendência.</p><div class="categories">${SECTIONS.map(s=>`<button class="category" onclick="Study.review('${s[0]}')"><span class="categorynum">↻</span><span class="categorytxt"><strong>${esc(s[1])}</strong><small>${o.pendingBySection[s[0]]||0} pendentes no histórico</small></span><span>›</span></button>`).join('')}</div><p class="notice">Os erros da sessão atual só entram na revisão quando você reabrir o aplicativo.</p></section>`;}
function exercise(){if(state.loading)return `<section class="page"><h1>Carregando exercícios…</h1></section>`;const e=state.lesson;if(!e)return done();const section=SECTIONS.find(s=>s[0]===state.section),bank=e.choices?null:tokens();const answered=state.result!==null;const quiz=e.choices?`<div class="sentence">${e.sentence.split(/(\s+)/).filter(t=>t.trim()).map(w=>`<button class="wordinline" onclick="Study.inspect('${encodeURIComponent(w)}')">${esc(w)} </button>`).join('')}</div><div class="choices">${e.choices.map((ch,i)=>`<button class="choice ${state.choice===i?(state.result==='good'?'correct':'incorrect'):''}" onclick="Study.answer(${i})" ${answered?'disabled':''}><span class="letter">${String.fromCharCode(65+i)}</span><span>${esc(ch)}</span></button>`).join('')}</div>`:
 `<div class="assembled">${state.picked.length?state.picked.map((id,i)=>`<button class="selectedword" onclick="Study.remove(${i})">${esc(bank.find(w=>w.id===id)?.text||'')}</button>`).join(''):'<span class="placeholder">Sua frase aparecerá aqui…</span>'}</div><div class="wordbank">${bank.filter(w=>!state.picked.includes(w.id)).map(w=>`<button class="token" onclick="Study.choose(${w.id})" oncontextmenu="event.preventDefault();Study.inspectToken(${w.id});return false;">${esc(w.text)}</button>`).join('')}</div><div class="row space"><button class="linkbtn ${state.lookup?'mint':''}" onclick="Study.toggle('lookup')">⇄ ${state.lookup?'Consulta ligada':'Consultar palavra'}</button><button class="linkbtn" onclick="Study.clear()">↻ Limpar</button></div>${state.lookup?`<div class="lookupwords">${e.sentence.split(/\s+/).map(w=>`<button onclick="Study.inspect('${encodeURIComponent(w)}')">${esc(w)}</button>`).join('')}</div>`:''}<button class="button block" onclick="Study.verify()" ${(state.picked.length!==bank.length||state.result==='good'||state.result==='reveal')?'disabled':''}>Verificar frase ✓</button>`;
 const good=state.result==='good'||state.result==='reveal';const feedback=state.result?`<div class="feedback ${good?'good':'bad'}"><strong>${state.result==='reveal'?'Resposta revelada':good?'Muito bem!':'Ainda não. Veja a correção.'}</strong><p>${state.result==='bad'&&e.choices?`Resposta correta: <b>${esc(e.choices[e.correct])}</b>. `:''}${esc(e.explanation)}</p>${good?`<p class="correctline">${esc(e.choices?e.sentence.replace('___',e.choices[e.correct]):e.sentence)}</p>`:''}</div>`:'';
 return `<section class="page"><button class="back" onclick="Study.catalog('${section[3]}')">‹ Todas as seções</button><div class="row space lessonHead"><div><div class="tag">${state.mode==='review'?'REVISÃO':'TREINO CONTÍNUO'} · ${e.level}</div><h1>${esc(section[1])}</h1></div><span class="pill" id="runningClock">◷ ${mins(state.liveSeconds)}</span></div><div class="barlabel"><span>${state.queueIndex+1} de ${state.due.length} inéditos/pendentes nesta sessão</span><span>${Math.round(100*(state.queueIndex+1)/state.due.length)}%</span></div><div class="track"><i style="width:${100*(state.queueIndex+1)/state.due.length}%"></i></div><div class="card"><div class="context">● ${esc(e.context)}</div><h2>${e.choices?'Complete a frase':'Organize as palavras'}</h2><p class="prompt">${e.choices?'Escolha a alternativa mais adequada.':'Toque nas palavras na ordem certa. Tente novamente se precisar.'}</p>${quiz}<div class="toolbox"><button class="linkbtn" onclick="Study.toggle('hint')">💡 ${state.hint?'Ocultar dica':'Ver dica'}</button><button class="linkbtn" onclick="Study.toggle('translation')">⇄ ${state.translation?'Ocultar tradução':'Traduzir frase'}</button><button class="linkbtn" onclick="Study.speak()">◖ Ouvir</button></div>${state.hint?`<div class="info">${esc(e.hint)}</div>`:''}${state.translation?`<div class="info translation"><strong>Tradução contextual</strong><p>${esc(e.translation)}</p></div>`:''}${state.word?`<div class="info translation"><strong>Significado de “${esc(state.word)}”</strong><p>${esc(meaning(state.word))}</p><button class="linkbtn" onclick="Study.inspect('')">Fechar</button></div>`:''}${feedback}<div class="footeractions">${!e.choices&&!good?`<button class="button flat" onclick="Study.reveal()">Revelar resposta</button>`:''}${answered&&(e.choices||good)?`<button class="button" onclick="Study.next()">Próximo →</button>`:''}${state.result==='bad'&&!e.choices?'<span class="notice">Você pode reorganizar as palavras e tentar novamente.</span>':''}</div></div></section>`;
}
function done(){return `<section class="page"><div class="finish"><div class="tag">✓ ETAPA CONCLUÍDA</div><h1>${state.mode==='review'?'Revisão concluída!':'Você concluiu os exercícios disponíveis!'}</h1><p>Você pode escolher outra seção, revisar as dificuldades ou consultar seu relatório mensal. Quando incluirmos novos lotes, eles aparecerão automaticamente como inéditos.</p><button class="button" onclick="Study.go('home')">Voltar ao início</button><button class="button ghost" onclick="Study.go('review')">Revisar dificuldades</button></div></section>`;}
function calendar(o){const [y,m]=state.month.split('-').map(Number),start=new Date(y,m-1,1).getDay(),days=new Date(y,m,0).getDate(),times=Object.fromEntries((o.calendar||[]).map(x=>[x.day,x.seconds]));return `<div class="cal"><div class="calheader"><button onclick="Study.month(-1)">‹</button><strong>${esc(displayMonth())}</strong><button onclick="Study.month(1)">›</button></div><div class="calgrid">${['D','S','T','Q','Q','S','S'].map(d=>`<span class="weekday">${d}</span>`).join('')}${Array.from({length:start},()=>'<div></div>').join('')}${Array.from({length:days},(_,i)=>{const d=state.month+'-'+pad(i+1);return `<button class="datebtn ${d===state.date?'selected':''}" onclick="Study.day('${d}')">${i+1}<i class="${times[d]?'studied':''}"></i></button>`;}).join('')}</div></div>`;}
function progress(){const o=overview(),d=o.day||{},by=d.sections||{};return `<section class="page"><div class="tag">HISTÓRICO DE ESTUDOS</div><h1>My Progress</h1><p class="intro">O tempo se acumula entre sessões e pausa quando o aplicativo sai da tela ou fica 90 segundos sem interação.</p><div class="cards2"><div class="stat"><small>TEMPO DO DIA SELECIONADO</small><strong>${mins(d.seconds||0)}</strong><p>Meta: ${mins(o.goal*60)}</p><div class="track"><i style="width:${Math.min(100,100*(d.seconds||0)/(o.goal*60))}%"></i></div></div><div class="stat"><small>CONCLUÍDOS NO DIA</small><strong>${d.newCount||0}</strong><p>${d.firstCount||0} de primeira</p></div></div><div class="goal"><span>Meta diária</span>${[120,150,180].map(n=>`<button class="${o.goal===n?'active':''}" onclick="Study.goal(${n})">${mins(n*60)}</button>`).join('')}</div>${calendar(o)}<div class="day"><div class="tag">DIA SELECIONADO · ${state.date.split('-').reverse().join('/')}</div><strong>${mins(d.seconds||0)}</strong><p>${d.newCount||0} exercícios novos concluídos · ${d.attempts||0} tentativas</p>${SECTIONS.map(s=>by[s[0]]?`<div class="row space dayrow"><span>${esc(s[1])}</span><b>${mins(by[s[0]])}</b></div>`:'').join('')}</div><div class="backup"><button class="button ghost" onclick="Study.backup()">↓ Salvar backup do progresso</button><button class="button flat" onclick="Study.restore()">↑ Restaurar backup</button></div><button class="button block" onclick="Study.go('report')">Ver relatório mensal →</button></section>`;}
function reportLevel(r){const secActive=Object.values(r.sections||{}).filter(s=>s.newCount>=3).length;if(r.newCount<40||secActive<5)return 'Amostra insuficiente';const c1Rate=r.c1Count?Math.round(100*r.c1First/r.c1Count):0;if(r.c1Count>=30&&c1Rate>=90&&r.accuracy>=90)return 'C1 — Consolidado*';if(r.c1Count>=12&&c1Rate>=80&&r.accuracy>=85)return 'C1 — Em desenvolvimento*';if(r.accuracy>=92)return 'B2 — Excelente*';if(r.accuracy>=84)return 'B2 — Consolidado*';if(r.accuracy>=73)return 'B2 — Em desenvolvimento*';return r.accuracy>=60?'B1+*':'B1*';}
function reportAnalysis(r,prev){if(r.newCount<10)return 'Ainda há poucos exercícios inéditos concluídos neste mês para identificar tendências. Continue praticando diferentes seções.';
 const rates=SECTIONS.map(s=>{const p=r.sections?.[s[0]]||{};return {...s,n:p.newCount||0,rate:p.newCount?Math.round(100*(p.firstCount||0)/p.newCount):0};});
 const eligible=rates.filter(x=>x.n>=3).sort((a,b)=>a.rate-b.rate);let text=`Você concluiu ${r.newCount} exercícios inéditos, com ${r.accuracy}% de acertos na primeira tentativa.`;
 if(prev.newCount>=10)text+=` No mês anterior, sua precisão foi de ${prev.accuracy}% (${r.accuracy>=prev.accuracy?'+':''}${r.accuracy-prev.accuracy} pontos percentuais).`;
 if(eligible.length>=2){text+=` Priorize ${eligible[0][1]}, com ${eligible[0].rate}% de acertos em ${eligible[0].n} exercícios. Seu melhor resultado com amostra suficiente foi ${eligible[eligible.length-1][1]} (${eligible[eligible.length-1].rate}%).`;}
 text+=` Você consultou dicas em ${r.hints} tentativas e realizou ${r.reviewAttempts} tentativas de revisão. Pratique também a construção oral de frases sem consultar as respostas.`;
 return text;
}
function reportText(o){const r=o.selected||blankStats(),p=o.previous||blankStats();return ['ENGLISH LAB · MONTHLY PERFORMANCE',`Mês: ${state.month}`,`Tempo: ${mins(r.seconds||0)}`,`Inéditos concluídos: ${r.newCount||0}`,`Acerto inicial: ${r.newCount?r.accuracy+'%':'Sem dados'}`,`Evolução (mês anterior): ${p.newCount>=10?p.accuracy+'%':'Sem amostra comparável'}`,`Classificação interna: ${reportLevel(r)}`,...SECTIONS.map(s=>{const d=r.sections?.[s[0]]||{};return `${s[1]}: ${d.newCount||0} inéditos; ${d.newCount?Math.round(100*(d.firstCount||0)/d.newCount)+'%':'sem dados'}; ${mins(d.seconds||0)}`;}),`Análise automática: ${reportAnalysis(r,p)}`,'Indicador de desempenho no app, não certificação CEFR.'].join('\n');}
function report(){const o=overview(),r=o.selected||blankStats(),p=o.previous||blankStats();return `<section class="page"><div class="tag">ENGLISH PERFORMANCE</div><h1>Monthly Overview</h1><p class="intro">Acompanhamento mensal baseado nos exercícios inéditos efetivamente concluídos.</p><div class="calheader"><button onclick="Study.month(-1)">‹</button><strong>${esc(displayMonth())}</strong><button onclick="Study.month(1)">›</button></div><div class="reporthero"><div class="tag">NÍVEL INTERNO NAS ATIVIDADES</div><h2>${esc(reportLevel(r))}</h2><p>* Classificação experimental. Não é certificado CEFR nem mede toda a fala, escuta e escrita livre.</p></div><div class="cards2"><div class="stat"><small>TEMPO DO MÊS</small><strong>${mins(r.seconds||0)}</strong></div><div class="stat"><small>ACERTOS DE PRIMEIRA</small><strong>${r.newCount?r.accuracy+'%':'—'}</strong><p>${r.newCount||0} inéditos concluídos</p></div></div><div class="reportbox"><h3>Comparação com o mês anterior</h3><p>Anterior: ${p.newCount||0} inéditos · ${p.newCount?p.accuracy+'%':'Sem amostra'} de acertos iniciais</p><p>Atual: ${r.newCount||0} inéditos · ${r.newCount?r.accuracy+'%':'Sem amostra'}</p></div><div class="reportbox skills"><h3>Desempenho por seção</h3>${SECTIONS.map(s=>{const d=r.sections?.[s[0]]||{},pct=d.newCount?Math.round(100*(d.firstCount||0)/d.newCount):0;return `<div class="skill"><div class="row space"><span>${esc(s[1])}</span><b>${d.newCount?pct+'%':'—'}</b></div><div class="track"><i style="width:${pct}%"></i></div><small>${d.newCount||0} inéditos · ${mins(d.seconds||0)}</small></div>`;}).join('')}</div><div class="reportbox"><div class="tag">✧ ANÁLISE AUTOMÁTICA</div><p>${esc(reportAnalysis(r,p))}</p></div><div class="row reportbuttons noprint"><button class="button" onclick="Study.share()">↗ Compartilhar resumo</button><button class="button ghost" onclick="Study.pdf()">▤ Salvar PDF</button></div></section>`;}
function render(){let html;switch(state.screen){case 'catalog':html=catalogView();break;case 'exercise':html=exercise();break;case 'progress':html=progress();break;case 'report':html=report();break;case 'review':html=reviewView();break;case 'done':html=done();break;case 'error':html=`<section class="page"><h1>Erro ao carregar</h1><p>${esc(state.notice)}</p><button class="button" onclick="Study.go('home')">Voltar</button></section>`;break;default:html=home();}
 const root=$('app');if(root)root.innerHTML=header()+alertHtml()+html+nav();}
function share(){const text=reportText(overview());if(native)window.Native.shareReport(text);else if(navigator.share)navigator.share({title:'English Lab',text}).catch(()=>{});else alert(text);}
function pdf(){flushTime();render();if(native)window.Native.exportPdf();else window.print();}
function backup(){flushTime();if(native)window.Native.exportBackup();else{alert('Backup pelo sistema disponível no aplicativo Android.');}}
function restore(){if(!confirm('Restaurar um backup substituirá todo o progresso atual. Deseja continuar?'))return;if(native)window.Native.importBackup();else alert('Restauração disponível no aplicativo Android.');}
function setGoal(goal){if(native)window.Native.setGoal(goal);else browserStore.goal(goal);render();}
function toggle(key){state[key]=!state[key];render();}
function inspect(w){state.word=w?decodeURIComponent(w):null;render();}
function inspectToken(id){if(!state.lesson)return;const token=tokens().find(w=>w.id===id);state.word=token?.text||null;render();}
function clear(){if(state.result==='good'||state.result==='reveal')return;state.picked=[];state.result=null;render();}
function back(){if(state.screen==='exercise')catalog(SECTIONS.find(s=>s[0]===state.section)?.[3]||'builder');else go('home');}
window.Study={go,catalog,lesson:openLesson,review:key=>openLesson(key,'review'),next,answer:quizAnswer,choose:chooseToken,remove:removeToken,verify:checkBuilder,reveal,toggle,inspect,inspectToken,speak:speech,clear,goal:setGoal,month:chooseMonth,day:d=>{flushTime();state.date=d;render();},share,pdf,backup,restore,dismiss:()=>{state.notice='';render();}};
window.studyPause=()=>{flushTime();lastTick=Date.now();lastActivity=0;};
window.studyResume=()=>{lastTick=Date.now();lastActivity=Date.now();};
window.studyBack=back;
window.studyNotice=notify;
let lastActivity=Date.now(),lastTick=Date.now(),lastFlush=Date.now();
window.addEventListener('pointerdown',()=>{lastActivity=Date.now();},{passive:true});
window.addEventListener('keydown',()=>{lastActivity=Date.now();});
document.addEventListener('visibilitychange',()=>{flushTime();lastTick=Date.now();if(!document.hidden)lastActivity=Date.now();});
window.addEventListener('pagehide',flushTime);
setInterval(()=>{const now=Date.now(),seconds=Math.min(2,Math.max(0,(now-lastTick)/1000));lastTick=now;
 if(state.screen==='exercise'&&!state.loading&&state.lesson&&document.visibilityState==='visible'&&now-lastActivity<90000){const key=dateKey()+'|'+state.section;state.secondsPending[key]=(state.secondsPending[key]||0)+seconds;state.liveSeconds+=seconds;const clock=$('runningClock');if(clock)clock.textContent='◷ '+mins(state.liveSeconds);}
 if(now-lastFlush>=8000){flushTime();lastFlush=now;}
},1000);
// Import the old localStorage once if the native v1 SharedPreferences had no data.
if(native){try{const old=localStorage.getItem('englishLabData');if(old)window.Native.migrateLocal(old);}catch{}}
render();
})();
