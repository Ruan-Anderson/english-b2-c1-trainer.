plugins {
    id("com.android.application")
}

android {
    namespace = "com.englishlab.trainer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.englishlab.trainer"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.0.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
