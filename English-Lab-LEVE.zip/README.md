# English Lab B2–C1 — projeto Android com 90.000 exercícios

**Este é um único projeto Android completo, não uma demonstração limitada a 45 ou 90 atividades.** O banco está incluído nos assets offline e possui exatamente **90.000 registros distribuídos entre nove seções, com 10.000 em cada uma**.

| Módulo | Seção | Exercícios |
|---|---|---:|
| Quiz | Modal Verbs | 10.000 |
| Quiz | Verb Patterns | 10.000 |
| Quiz | Conditionals | 10.000 |
| Quiz | Prepositions | 10.000 |
| Quiz | Get / Got / Getting / Gotten | 10.000 |
| Formador de Frases | Build the Sentence | 10.000 |
| Formador de Frases | Present Perfect | 10.000 |
| Formador de Frases | Word Order | 10.000 |
| Formador de Frases | Phrasal Verbs | 10.000 |
| **TOTAL** | | **90.000** |

## Funcionalidades incluídas no código

- Quiz com três alternativas por questão, dicas, correção e explicação em português brasileiro.
- Formador de Frases com tokens embaralhados, reordenação, novas tentativas, resposta revelada e variantes previamente cadastradas.
- Treino contínuo com botão **Próximo**, inclusive passagem automática entre as nove seções, preservando escolha manual.
- Consulta de palavras e de frases completas, com vocabulário vinculado ao contexto e reprodução oral do inglês americano via TTS do Android.
- Armazenamento persistente em **SQLite** de tentativas, conclusões individuais por ID, erros pendentes de revisão, tempo de prática e metas.
- Cronômetro acumulativo: pausa ao sair da tela ou após 90 segundos sem atividade; calendário e histórico diário.
- Estatísticas, classificação interna experimental, análise mensal, opção de imprimir PDF e backup/restauração do progresso.
- Conteúdo offline dividido em nove arquivos JSON carregados sob demanda, um por seção. Arquivos `.js` espelhados permitem pré-visualização no navegador.

## Qualidade e limites da validação

Os primeiros **90 exercícios foram escritos individualmente no projeto anterior** e seus IDs foram preservados. Os **89.910 restantes foram gerados por composição determinística de estruturas gramaticais, tópicos, situações e cláusulas contextuais**, acompanhados por traduções, dicas e explicações de padrão. São 90.000 enunciados normalizados *exatamente diferentes*, conforme testes automatizados.

**Isso não equivale à revisão editorial individual de 89.910 exercícios.** Sem auditoria linguística independente, não é possível garantir ausência de frases artificiais, variações conceitualmente próximas, tradução discutível ou respostas ambíguas. O projeto não afirma ter passado por essa revisão. A classificação CEFR é **indicador interno experimental**, não certificação.

## Compilação do APK

Requisitos: JDK 17, Gradle 8.13, Android SDK 35, Android Gradle Plugin 8.9.2. No terminal na raiz:

```bash
node tests/validate_content.cjs
node tests/flow.cjs
python3 tests/validate_sqlite.py
gradle :app:assembleDebug
```

APK gerado em `app/build/outputs/apk/debug/app-debug.apk`. Também há o workflow `.github/workflows/build-apk.yml`, que faz a compilação no GitHub Actions e disponibiliza o APK como artefato da execução.

**O APK não está neste ZIP.** A compilação e a instalação em dispositivo/emulador devem ser realizadas e confirmadas no ambiente de desenvolvimento. Para atualizar uma instalação existente sem desinstalar, a assinatura deve ser a **mesma chave do APK anterior** e o `versionCode` precisa ser maior; este projeto usa `applicationId=com.englishlab.trainer` e `versionCode=3`. Se não houver acesso à chave anterior, faça backup do progresso antes de qualquer reinstalação.

Os bancos de exercícios e os testes estão todos **incluídos agora**. O README do repositório GitHub existente deverá ser preservado ao enviar o projeto ao remoto.
