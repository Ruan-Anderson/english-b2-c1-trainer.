'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const folder=path.resolve(__dirname,'../app/src/main/assets/content');
const keys=['modals','patterns','conditionals','prepositions','get','build','perfect','order','phrasals'];
const prefixes=['m','v','c','p','g','b','t','o','h'];
const ctx=vm.createContext({window:{}});
vm.runInContext(fs.readFileSync(path.join(folder,'manifest.js'),'utf8'),ctx);
const manifest=ctx.window.EXERCISE_MANIFEST;
assert.equal(manifest.targetTotal,90000);
assert.equal(manifest.validatedTotal,90000);
assert.equal(manifest.generatedRuleBasedTotal,89910);
const normalized=s=>s.normalize('NFKC').replace(/[’]/g,"'").toLowerCase().replace(/[^a-z0-9\s]/g,'').replace(/\s+/g,' ').trim();
const wordBag=s=>s.toLowerCase().replace(/[^a-z\s-]/g,'').split(/\s+/).sort().join(' ');
const old45=JSON.parse(fs.readFileSync(path.join(__dirname,'legacy_45.json'),'utf8'));
const oldMap=new Map(old45.map(e=>[e.id,e.sentence]));
const allIDs=new Set(),allSentences=new Set();let authored=0,synthetic=0,total=0;
const report=[];
for(let i=0;i<keys.length;i++){
 const key=keys[i],records=JSON.parse(fs.readFileSync(path.join(folder,key+'.json'),'utf8'));
 assert.equal(records.length,10000,`${key}: must contain 10,000 exercises`);
 assert.equal(records.length,manifest.sections[key]);
 let quiz=0,builder=0;
 for(let j=0;j<records.length;j++){
  const e=records[j];total++;
  assert.equal(e.id,prefixes[i]+(j+1),`${key}: stable sequential ID`);
  assert(!allIDs.has(e.id),'duplicate ID: '+e.id);allIDs.add(e.id);
  assert.equal(e.category,key,e.id);
  assert(['B2','C1'].includes(e.level),e.id);
  for(const k of ['context','sentence','translation','hint','explanation'])
   assert(typeof e[k]==='string'&&e[k].trim().length>=12,`${e.id}: missing ${k}`);
  const phrase=normalized(e.sentence);assert(!allSentences.has(phrase),'duplicated prompt: '+e.id);allSentences.add(phrase);
  if(oldMap.has(e.id))assert.equal(e.sentence,oldMap.get(e.id),`${e.id}: original sentence was modified`);
  if(j<10){assert(/^core-00[12]$/.test(e.batch),e.id);authored++;}
  else{assert.equal(e.origin,'rule-generated',e.id);synthetic++;}
  if(i<5){
   quiz++;
   assert.equal(e.sentence.split('___').length,2,`${e.id}: quiz blank invalid`);
   assert(Array.isArray(e.choices)&&e.choices.length===3,e.id);
   assert.equal(new Set(e.choices.map(normalized)).size,3,e.id);
   assert(Number.isInteger(e.correct)&&e.correct>=0&&e.correct<3,e.id);
  }else{
   builder++;
   assert(e.sentence.split(/\s+/).length>=9,`${e.id}: builder too short`);
   assert(e.vocab&&typeof e.vocab==='object'&&!Array.isArray(e.vocab),e.id);
   for(const alt of e.accepted||[])assert.equal(wordBag(alt),wordBag(e.sentence),`${e.id}: alternative changes tokens`);
  }
 }
 const digest=crypto.createHash('sha256').update(fs.readFileSync(path.join(folder,key+'.json'))).digest('hex');
 report.push({section:key,count:records.length,quiz,builder,sha256:digest});
 console.log(`PASS ${key.padEnd(15)} 10.000 registros / SHA256 ${digest.slice(0,14)}`);
}
assert.equal(total,90000);assert.equal(allIDs.size,90000);assert.equal(allSentences.size,90000);
assert.equal(authored,90);assert.equal(synthetic,89910);
fs.writeFileSync(path.join(__dirname,'validation-report.json'),JSON.stringify({total,uniqueIds:allIDs.size,uniquePrompts:allSentences.size,authored,synthetic,fullEditorialReviewComplete:false,checks:'schema, options, answer indexes, exact normalized duplicate check, stable IDs, preserved legacy 45',sections:report},null,2)+'\n');
console.log('PASS: 90.000 IDs únicos e 90.000 enunciados normalizados únicos.');
console.log('PASS: 50.000 quizzes, 40.000 formadores; IDs originais preservados.');
console.log('SCOPE: 89.910 frases criadas por composição gramatical e validadas automaticamente; nenhuma alegação de revisão editorial individual completa.');
