"""Offline schema/index smoke tests. Does not replace Android instrumentation tests."""
from pathlib import Path
import sqlite3, re
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/englishlab/trainer/StudyStore.java').read_text()
sqls=re.findall(r'db\.execSQL\("(CREATE (?:TABLE|INDEX) [^"\\]+)"\);',s)
assert len(sqls)>=9, (len(sqls),sqls)
conn=sqlite3.connect(':memory:')
for sql in sqls: conn.execute(sql)
for table in ['attempts','completions','reviews','study_time','settings']:
    assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone(),table
conn.execute("INSERT INTO completions(exercise_id,section,finished_at,day,first_try,level) VALUES ('m1','modals',1,'2026-11-22',1,'B2')")
try:conn.execute("INSERT INTO completions(exercise_id,section,finished_at,day,first_try,level) VALUES ('m1','modals',2,'2026-11-22',0,'B2')")
except sqlite3.IntegrityError: pass
else: raise AssertionError('Completions allowed duplicate IDs')
assert conn.execute('SELECT COUNT(*) FROM completions').fetchone()[0]==1
for table,index in [('attempts','attempts_exercise_idx'),('attempts','attempts_section_idx'),('attempts','attempts_day_idx'),('completions','completions_section_idx'),('completions','completions_day_idx'),('reviews','reviews_section_idx'),('study_time','study_time_day_idx')]:
    assert any(idx[1]==index for idx in conn.execute(f'PRAGMA index_list({table})')),(table,index)
print('PASS: SQLite schemas and seven indexes parse; completion key rejects duplicate exercise IDs.')
