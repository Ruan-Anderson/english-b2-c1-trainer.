'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const ASSETS=path.resolve(__dirname,'../app/src/main/assets'),persistent=new Map();
function session(){
 let html='';let ctx;
 const document={visibilityState:'visible',hidden:false,
  getElementById(id){if(id==='app')return{get innerHTML(){return html;},set innerHTML(v){html=v;}};return{textContent:''};},
  addEventListener(){},head:{appendChild(el){const text=fs.readFileSync(path.join(ASSETS,el.src),'utf8');vm.runInContext(text,ctx);el.onload?.();}},
  createElement(){return{src:'',onload:null,onerror:null};}};
 const localStorage={getItem:k=>persistent.get(k)||null,setItem:(k,v)=>persistent.set(k,v)};
 const window={EXERCISE_MANIFEST:null,EXERCISE_DATA:{},addEventListener(){}};
 ctx=vm.createContext({window,localStorage,document,Date,Math,JSON,String,Array,Set,Map,Object,Promise,console,Intl,encodeURIComponent,decodeURIComponent,setInterval(){},navigator:{},confirm:()=>true,alert:()=>{}});
 vm.runInContext(fs.readFileSync(path.join(ASSETS,'content/manifest.js'),'utf8'),ctx);
 vm.runInContext(fs.readFileSync(path.join(ASSETS,'app.js'),'utf8'),ctx);
 return {Study:window.Study,ctx,html:()=>html};
}
const tick=()=>new Promise(r=>setTimeout(r,0));
(async()=>{
 let s=session();assert.match(s.html(),/90\.000 exercícios/);
 s.Study.catalog('quiz');assert.match(s.html(),/Modal Verbs/);
 await s.Study.lesson('modals');await tick();
 assert.match(s.html(),/1 de 10000 inéditos\/pendentes/);
 s.Study.answer(0);assert.match(s.html(),/Ainda não/);
 assert.match(s.html(),/Tradução contextual/);
 await s.Study.next();await tick();assert.match(s.html(),/2 de 10000 inéditos\/pendentes/);
 s.Study.answer(s.ctx.window.EXERCISE_DATA.modals[1].correct);await s.Study.next();await tick();
 const initial=JSON.parse(persistent.get('englishLabV2'));
 assert.equal(new Set(initial.attempts.filter(x=>x.final).map(x=>x.exerciseId)).size,2);
 assert(initial.attempts.some(x=>x.exerciseId==='m1'&&!x.correct));
 s=session();await s.Study.review('modals');await tick();
 assert.match(s.html(),/REVISÃO/);assert.match(s.html(),/1 de 1 inéditos\/pendentes/);
 const original=s.ctx.window.EXERCISE_DATA.modals[0];s.Study.answer(original.correct);await s.Study.next();
 assert.match(s.html(),/Revisão concluída/);
 s=session();await s.Study.review('modals');await tick();assert.match(s.html(),/Você concluiu os exercícios disponíveis|Revisão concluída/);
 await s.Study.lesson('build');await tick();assert.match(s.html(),/Organize as palavras/);
 s.Study.reveal();assert.match(s.html(),/Resposta revelada/);
 await s.Study.next();await tick();assert.match(s.html(),/2 de 10000 inéditos\/pendentes/);
 s.Study.go('progress');assert.match(s.html(),/My Progress/);
 s.Study.go('report');assert.match(s.html(),/Monthly Overview/);
 const now=JSON.parse(persistent.get('englishLabV2'));
 assert.equal(new Set(now.attempts.filter(x=>x.final).map(x=>x.exerciseId)).size,3);
 assert.equal(now.attempts.filter(x=>x.exerciseId==='m1').length,2);
 assert.equal(now.attempts.filter(x=>x.exerciseId==='b1'&&!x.correct).length,1);
 console.log('PASS: quiz, hints, translation, unique completions, review after restart, reveal builder, progress and report.');
 // Test automatic handoff without playing all ten thousand exercises: seed the
 // same persisted completion entries that a full training history would contain.
 const day='2026-11-21',ts=Date.now()-3600000;
 const attempts=Array.from({length:9999},(_,i)=>({exerciseId:'m'+(i+1),section:'modals',day,timestamp:ts,correct:true,firstTry:true,hint:false,translation:false,attemptNumber:1,final:true,review:false,level:'B2'}));
 persistent.set('englishLabV2',JSON.stringify({attempts,times:{},goal:150}));
 s=session();await s.Study.lesson('modals');await tick();
 assert.match(s.html(),/1 de 1 inéditos\/pendentes/);
 const rows=s.ctx.window.EXERCISE_DATA.modals,final=rows[rows.length-1];
 assert.equal(final.id,'m10000');s.Study.answer(final.correct);await s.Study.next();await tick();
 assert.match(s.html(),/Verb Patterns/);assert.match(s.html(),/1 de 10000 inéditos\/pendentes/);
 console.log('PASS: after 10,000th modal, Próximo loads first unseen Verb Patterns item automatically.');
})().catch(e=>{console.error(e);process.exitCode=1;});
