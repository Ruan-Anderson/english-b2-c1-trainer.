#!/usr/bin/env python3
"""Deterministic bilingual grammar-constraint authoring and offline package generation.

Uses core 90 authored exercises unmodified; generates compositional contextual
practice material with automatic schema, answer and duplicate checks.
Does NOT substitute for human editorial review of all 89,910 additions.
"""
import json, re, hashlib, pathlib, math, random, unicodedata
from collections import Counter, defaultdict
BASE=pathlib.Path(__file__).resolve().parents[1]
CONTENT=BASE/'app/src/main/assets/content'
ORDER=['modals','patterns','conditionals','prepositions','get','build','perfect','order','phrasals']
PREFIX=dict(zip(ORDER,list('mvcpgbtoh')))
ORIGINAL=json.loads((BASE/'tests/core_90.json').read_text('utf-8'))

# Each topic is an abstract plan, arrangement, decision, or set of details.
# All domain verbs are chosen to form idiomatic verb-object combinations.
DOMAIN_SEEDS=[
('Varejo · Operações', 'Retail operations',
 '''the latest inventory allocation|a distribuição mais recente do estoque;the revised store targets|as metas revisadas das lojas;the next promotional calendar|o próximo calendário promocional;the price adjustment proposal|a proposta de ajuste de preços;the outlet transfer schedule|o cronograma de transferências do outlet;the stock reconciliation report|o relatório de conciliação de estoque;the customer feedback summary|o resumo das avaliações dos clientes;the seasonal markdown plan|o plano de remarcação sazonal;the supplier delivery forecast|a previsão de entregas do fornecedor;the store staffing schedule|a escala de funcionários da loja;the weekend sales strategy|a estratégia de vendas do fim de semana;the visual merchandising guidelines|as orientações de visual merchandising;the regional performance figures|os indicadores de desempenho regional;the new product launch checklist|a lista de verificação do novo lançamento;the branch replenishment plan|o plano de reposição da filial;the team training schedule|o cronograma de treinamento da equipe''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Trabalho · Projetos', 'Work projects',
 '''the quarterly budget proposal|a proposta de orçamento trimestral;the cross-team meeting agenda|a pauta da reunião entre equipes;the revised project timeline|o cronograma revisado do projeto;the client onboarding plan|o plano de integração do cliente;the weekly priorities list|a lista de prioridades da semana;the stakeholder communication plan|o plano de comunicação com as partes interessadas;the technical requirements document|o documento de requisitos técnicos;the product release schedule|o calendário de lançamento do produto;the team responsibilities chart|o quadro de responsabilidades da equipe;the supplier negotiation strategy|a estratégia de negociação com o fornecedor;the process improvement proposal|a proposta de melhoria de processos;the employee training materials|os materiais de treinamento dos funcionários;the meeting follow-up notes|as anotações de acompanhamento da reunião;the presentation outline|o roteiro da apresentação;the expense approval workflow|o fluxo de aprovação de despesas;the department performance report|o relatório de desempenho do departamento''',
 ['review','double-check','update','clarify','finalize','discuss']),
('Viagem · Planejamento', 'Travel planning',
 '''the hotel check-in arrangements|os preparativos de check-in do hotel;the airport transfer details|os detalhes do traslado do aeroporto;the revised flight itinerary|o itinerário revisado do voo;the travel insurance coverage|a cobertura do seguro de viagem;the train connection schedule|os horários das conexões de trem;the rental car reservation|a reserva do carro alugado;the luggage allowance information|as informações sobre franquia de bagagem;the passport renewal timeline|o cronograma de renovação do passaporte;the sightseeing route plan|o roteiro de passeios turísticos;the return journey arrangements|os preparativos da viagem de volta;the accommodation booking details|os detalhes da reserva de hospedagem;the airport pickup instructions|as instruções para o traslado do aeroporto;the foreign currency budget|o orçamento de moeda estrangeira;the international roaming options|as opções de roaming internacional;the emergency contact information|as informações de contatos de emergência;the travel documentation checklist|a lista de documentos para a viagem''',
 ['review','double-check','update','clarify','finalize','discuss']),
('Família · Organização', 'Family planning',
 '''the baby's bedtime routine|a rotina de sono do bebê;the pediatrician appointment details|os detalhes da consulta pediátrica;the family weekend arrangements|os preparativos do fim de semana em família;the daycare enrollment paperwork|a documentação de matrícula na creche;the baby's feeding schedule|os horários de alimentação do bebê;the household childcare plan|o plano de cuidados infantis da casa;the stroller safety checklist|a lista de segurança do carrinho;the family holiday itinerary|o roteiro de férias da família;the baby supplies inventory|o controle de suprimentos do bebê;the children's activity schedule|o cronograma de atividades das crianças;the family emergency plan|o plano de emergência familiar;the school pickup arrangements|os preparativos para buscar as crianças na escola;the family's weekly appointments|os compromissos semanais da família;the nighttime care rotation|o revezamento de cuidados noturnos;the home safety precautions|as precauções de segurança da casa;the vaccination appointment schedule|o cronograma de consultas para vacinação''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Casa · Rotina', 'Household routines',
 '''the weekly grocery budget|o orçamento semanal de compras;the household maintenance schedule|o cronograma de manutenção da casa;the apartment cleaning plan|o plano de limpeza do apartamento;the laundry rotation schedule|a escala de lavagem de roupas;the internet installation arrangements|os preparativos de instalação da internet;the home office setup plan|o plano de montagem do escritório em casa;the monthly utility payments|os pagamentos mensais de serviços;the kitchen storage layout|a organização do armazenamento da cozinha;the energy-saving measures|as medidas de economia de energia;the weekend repair checklist|a lista de reparos do fim de semana;the household recycling plan|o plano de reciclagem doméstica;the home security settings|as configurações de segurança da casa;the moving day schedule|o cronograma do dia da mudança;the apartment inspection report|o relatório de vistoria do apartamento;the delivery access instructions|as instruções de acesso para entregas;the shared household calendar|o calendário doméstico compartilhado''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Finanças · Planejamento', 'Personal finances',
 '''the monthly spending plan|o plano de gastos mensais;the emergency savings target|a meta de reserva de emergência;the apartment down payment strategy|a estratégia para a entrada do apartamento;the household cash flow forecast|a previsão de fluxo de caixa doméstico;the annual insurance budget|o orçamento anual de seguros;the credit card payment schedule|o cronograma de pagamento do cartão;the mortgage repayment options|as opções de pagamento do financiamento;the children's education budget|o orçamento de educação das crianças;the family investment allocation|a distribuição dos investimentos da família;the car financing proposal|a proposta de financiamento do carro;the retirement contribution plan|o plano de contribuições para a aposentadoria;the unexpected expenses fund|o fundo para despesas imprevistas;the next salary negotiation plan|o plano da próxima negociação salarial;the recurring subscriptions list|a lista de assinaturas recorrentes;the household tax documentation|a documentação tributária da família;the vacation savings schedule|o cronograma de poupança para férias''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Estudos · Idiomas', 'Language learning',
 '''the daily English practice schedule|o cronograma de prática diária de inglês;the pronunciation training plan|o plano de treinamento de pronúncia;the list of recurring grammar errors|a lista de erros gramaticais recorrentes;the listening comprehension routine|a rotina de compreensão auditiva;the vocabulary review schedule|o cronograma de revisão de vocabulário;the conversation practice goals|as metas de prática de conversação;the next speaking assessment|a próxima avaliação de conversação;the weekly writing assignments|as tarefas semanais de redação;the business English study plan|o plano de estudo de inglês profissional;the American accent exercises|os exercícios de sotaque americano;the monthly language progress report|o relatório mensal de progresso no idioma;the phrasal verb revision list|a lista de revisão de phrasal verbs;the advanced reading schedule|o cronograma de leitura avançada;the grammar challenge sequence|a sequência de desafios gramaticais;the interview preparation checklist|a lista de preparação para entrevistas;the daily shadowing sessions|as sessões diárias de shadowing''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Tecnologia · Organização', 'Technology projects',
 '''the application security settings|as configurações de segurança do aplicativo;the software deployment checklist|a lista de verificação de implantação do software;the database backup schedule|o cronograma de backup do banco de dados;the automation workflow design|o desenho do fluxo de automação;the mobile app testing plan|o plano de testes do aplicativo móvel;the cloud infrastructure budget|o orçamento de infraestrutura em nuvem;the service integration requirements|os requisitos de integração do serviço;the user feedback collection plan|o plano de coleta de feedback dos usuários;the product analytics dashboard|o painel de análise do produto;the password recovery procedure|o procedimento de recuperação de senha;the notification preference settings|as configurações de preferências de notificação;the application release notes|as notas de versão do aplicativo;the data migration schedule|o cronograma de migração de dados;the API access policy|a política de acesso à API;the quality assurance strategy|a estratégia de garantia de qualidade;the server maintenance plan|o plano de manutenção do servidor''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Moradia · Imóvel', 'Housing decisions',
 '''the apartment viewing schedule|o cronograma de visitas aos apartamentos;the property inspection checklist|a lista de verificação da vistoria do imóvel;the mortgage application documents|os documentos de solicitação de financiamento;the new lease agreement details|os detalhes do novo contrato de aluguel;the building maintenance charges|as taxas de manutenção do condomínio;the renovation cost estimate|a estimativa de custo da reforma;the neighborhood comparison notes|as anotações de comparação entre bairros;the moving company arrangements|os preparativos com a empresa de mudanças;the condominium meeting agenda|a pauta da reunião de condomínio;the home renovation timeline|o cronograma da reforma da casa;the furniture delivery schedule|o cronograma de entrega dos móveis;the property insurance coverage|a cobertura do seguro do imóvel;the apartment floor plan|a planta do apartamento;the home purchase budget|o orçamento de compra da casa;the shared utility arrangements|os acordos de serviços compartilhados;the real estate agent's proposal|a proposta do corretor de imóveis''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Transporte · Deslocamento', 'Transportation',
 '''the morning commute route|a rota do deslocamento matinal;the bus transfer schedule|os horários de conexão dos ônibus;the train service updates|as atualizações do serviço de trens;the vehicle maintenance checklist|a lista de manutenção do veículo;the daily parking arrangements|os preparativos de estacionamento diário;the fuel expense forecast|a previsão de gastos com combustível;the ride-sharing pickup details|os detalhes do embarque por aplicativo;the road trip itinerary|o roteiro de viagem de carro;the bicycle safety plan|o plano de segurança da bicicleta;the weekend traffic forecast|a previsão de trânsito do fim de semana;the public transit pass options|as opções de passe de transporte público;the airport shuttle schedule|os horários do transporte para o aeroporto;the vehicle insurance proposal|a proposta de seguro do veículo;the remote work travel policy|a política de deslocamento do trabalho remoto;the school bus arrangements|os preparativos do transporte escolar;the route accessibility information|as informações de acessibilidade da rota''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Amigos · Vida social', 'Social life',
 '''the dinner party arrangements|os preparativos do jantar entre amigos;the weekend gathering schedule|o cronograma do encontro de fim de semana;the birthday celebration plan|o plano de comemoração do aniversário;the group travel itinerary|o roteiro da viagem em grupo;the shared restaurant reservation|a reserva conjunta do restaurante;the volunteer event schedule|o cronograma do evento de voluntariado;the neighborhood get-together plans|os planos do encontro entre vizinhos;the family reunion logistics|a logística da reunião de família;the concert ticket arrangements|os preparativos dos ingressos do show;the friend's moving day plan|o plano de mudança do amigo;the community workshop schedule|o cronograma da oficina comunitária;the shared vacation budget|o orçamento compartilhado das férias;the game night guest list|a lista de convidados da noite de jogos;the event accessibility arrangements|os preparativos de acessibilidade do evento;the surprise celebration details|os detalhes da comemoração surpresa;the weekend hiking itinerary|o roteiro da caminhada do fim de semana''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Compras · Atendimento', 'Shopping and service',
 '''the online order details|os detalhes do pedido on-line;the delayed shipment report|o relatório da entrega atrasada;the product return instructions|as instruções de devolução do produto;the warranty coverage terms|os termos de cobertura da garantia;the subscription cancellation request|o pedido de cancelamento da assinatura;the customer service complaint|a reclamação ao atendimento ao cliente;the replacement item arrangements|os preparativos para o item de substituição;the delivery tracking information|as informações de rastreamento da entrega;the refund processing schedule|o cronograma de processamento do reembolso;the clothing alteration request|o pedido de ajuste de roupa;the online checkout options|as opções de pagamento on-line;the store pickup details|os detalhes da retirada na loja;the gift exchange arrangements|os preparativos para a troca de presente;the account verification steps|as etapas de verificação da conta;the service appointment schedule|o cronograma do atendimento agendado;the membership renewal proposal|a proposta de renovação da associação''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Cozinha · Alimentação', 'Meals and cooking',
 '''the weekly meal preparation plan|o plano semanal de preparo das refeições;the grocery delivery schedule|o cronograma de entrega das compras;the family dinner menu|o cardápio do jantar em família;the meal planning budget|o orçamento do planejamento alimentar;the restaurant booking arrangements|os preparativos da reserva do restaurante;the food storage instructions|as instruções de armazenamento de alimentos;the lunch break schedule|o cronograma do intervalo de almoço;the dietary preference notes|as anotações sobre preferências alimentares;the family recipe collection|a coleção de receitas da família;the cooking class arrangements|os preparativos da aula de culinária;the kitchen equipment maintenance plan|o plano de manutenção dos equipamentos da cozinha;the weekly shopping list|a lista de compras semanal;the birthday cake order details|os detalhes do pedido do bolo de aniversário;the dinner guest preferences|as preferências dos convidados do jantar;the special occasion menu|o cardápio da ocasião especial;the food waste reduction plan|o plano de redução do desperdício de alimentos''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Bem-estar · Rotina', 'Personal routines',
 '''the morning exercise schedule|o cronograma de exercícios matinais;the monthly wellness goals|as metas mensais de bem-estar;the weekend walking route|o percurso da caminhada do fim de semana;the sleep routine adjustments|os ajustes da rotina de sono;the annual checkup arrangements|os preparativos do check-up anual;the work-life balance plan|o plano de equilíbrio entre trabalho e vida pessoal;the fitness class schedule|o cronograma das aulas de atividade física;the household stress management plan|o plano familiar de controle do estresse;the regular medical appointment schedule|o cronograma de consultas médicas regulares;the daily hydration reminders|os lembretes diários de hidratação;the weekly exercise targets|as metas semanais de exercícios;the neighborhood running group schedule|o cronograma do grupo de corrida do bairro;the weekend rest arrangements|os preparativos de descanso do fim de semana;the family outdoor activity plan|o plano familiar de atividades ao ar livre;the personal time management routine|a rotina pessoal de gestão do tempo;the annual preventive care schedule|o cronograma anual de cuidados preventivos''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Hotelaria · Serviços', 'Hospitality and service',
 '''the front desk staffing schedule|a escala de pessoal da recepção;the guest check-in procedure|o procedimento de check-in dos hóspedes;the hotel reservation update plan|o plano de atualização das reservas do hotel;the room maintenance schedule|o cronograma de manutenção dos quartos;the customer experience survey|a pesquisa de experiência do cliente;the guest complaint follow-up plan|o plano de acompanhamento da reclamação do hóspede;the breakfast service arrangements|os preparativos do serviço de café da manhã;the late checkout policy|a política de saída tardia;the event room booking details|os detalhes da reserva da sala de eventos;the concierge service guide|o guia do serviço de concierge;the hotel accessibility information|as informações de acessibilidade do hotel;the reservation cancellation policy|a política de cancelamento de reservas;the travel agency partnership proposal|a proposta de parceria com a agência de viagens;the housekeeping checklist|a lista de verificação da equipe de limpeza;the conference guest itinerary|o roteiro dos hóspedes da conferência;the weekend occupancy forecast|a previsão de ocupação do fim de semana''',
 ['review','double-check','update','clarify','finalize','reconsider']),
('Criatividade · Projetos', 'Creative projects',
 '''the video production schedule|o cronograma de produção de vídeo;the website design proposal|a proposta de design do site;the social media content calendar|o calendário de conteúdo de redes sociais;the brand identity guidelines|as diretrizes de identidade visual da marca;the monthly campaign brief|o briefing mensal da campanha;the customer interview questions|as perguntas da entrevista com clientes;the video editing checklist|a lista de verificação da edição de vídeo;the portfolio presentation outline|o roteiro de apresentação do portfólio;the photography session arrangements|os preparativos da sessão de fotos;the creative project budget|o orçamento do projeto criativo;the content publishing schedule|o cronograma de publicação de conteúdo;the podcast episode plan|o plano do episódio de podcast;the newsletter launch details|os detalhes do lançamento da newsletter;the audience research summary|o resumo da pesquisa de público;the sponsorship proposal|a proposta de patrocínio;the promotional material layout|o layout do material promocional''',
 ['review','double-check','update','clarify','finalize','reconsider'])
]
VERBS={
 'review':('review','reviewed','reviewing','revisar'),
 'double-check':('double-check','double-checked','double-checking','conferir novamente'),
 'update':('update','updated','updating','atualizar'),
 'clarify':('clarify','clarified','clarifying','esclarecer'),
 'finalize':('finalize','finalized','finalizing','finalizar'),
 'reconsider':('reconsider','reconsidered','reconsidering','reconsiderar'),
 'discuss':('discuss','discussed','discussing','discutir'),
}
# Distinct framing clauses maintain grammatical agreement and consistent translations.
TIME=[
 ('before the next meeting','antes da próxima reunião'),
 ('before the deadline','antes do prazo final'),
 ('by Friday afternoon','até sexta-feira à tarde'),
 ('before everyone signs off','antes de todos encerrarem o expediente'),
 ('while there is still time to make changes','enquanto ainda há tempo para fazer mudanças'),
 ('before another round of questions comes in','antes que chegue outra rodada de perguntas'),
 ('ahead of the final discussion','antes da discussão final'),
 ('before the schedule becomes more crowded','antes que a agenda fique mais cheia'),
 ('before making a firm commitment','antes de assumir um compromisso definitivo'),
 ('while the details are still fresh','enquanto os detalhes ainda estão frescos na memória'),
 ('before we move on to the next step','antes de passarmos à próxima etapa'),
 ('as soon as the team is available','assim que a equipe estiver disponível'),
]
CAUSE=[
 ('the timeline has changed twice already','o cronograma já mudou duas vezes'),
 ('several people are waiting for a clear answer','várias pessoas estão esperando uma resposta clara'),
 ('the last update raised more questions than it answered','a última atualização gerou mais perguntas do que respostas'),
 ('we still do not have all the information','ainda não temos todas as informações'),
 ('the original plan has not worked as expected','o plano original não funcionou como esperado'),
 ('everyone is working with a different version','cada pessoa está trabalhando com uma versão diferente'),
 ('the next deadline is approaching faster than expected','o próximo prazo está chegando mais rápido que o esperado'),
 ('there is still some uncertainty about the details','ainda há alguma incerteza sobre os detalhes'),
 ('a small misunderstanding could cause a bigger delay','um pequeno mal-entendido poderia causar um atraso maior'),
 ('we have not received the final confirmation','ainda não recebemos a confirmação definitiva'),
 ('the details matter more than they first appeared to','os detalhes importam mais do que pareciam no começo'),
 ('the people involved have asked for greater clarity','as pessoas envolvidas pediram mais clareza'),
]
PAST=[
 ('the previous discussion ended without a decision','a discussão anterior terminou sem uma decisão'),
 ('the schedule changed unexpectedly','o cronograma mudou de forma inesperada'),
 ('we noticed a discrepancy in the information','percebemos uma divergência nas informações'),
 ('the team identified a possible misunderstanding','a equipe identificou um possível mal-entendido'),
 ('the last version was questioned by several people','a última versão foi questionada por várias pessoas'),
 ('we realized the original assumptions were incomplete','percebemos que as premissas iniciais estavam incompletas'),
 ('the initial request turned out to be more complicated','o pedido inicial acabou sendo mais complicado'),
 ('an unexpected delay changed the priorities','um atraso inesperado mudou as prioridades'),
 ('we found out that the details had been misunderstood','descobrimos que os detalhes haviam sido mal compreendidos'),
 ('the first attempt did not solve the problem','a primeira tentativa não resolveu o problema'),
]
CONSEQUENCE=[
 ('everyone could make a better-informed decision','todos poderiam tomar uma decisão mais bem informada'),
 ('we would avoid unnecessary back-and-forth','evitaríamos trocas de mensagens desnecessárias'),
 ('nobody would have to guess what comes next','ninguém teria que adivinhar qual é o próximo passo'),
 ('the next discussion would be far more productive','a próxima discussão seria muito mais produtiva'),
 ('we would have more room to adjust the plan','teríamos mais margem para ajustar o plano'),
 ('the entire process would run more smoothly','todo o processo funcionaria de maneira mais tranquila'),
 ('we could focus on the issues that actually matter','poderíamos nos concentrar nos problemas que realmente importam'),
 ('everyone involved would know where things stand','todos os envolvidos saberiam como está a situação'),
]

class Scene:
 def __init__(self,domain, enobj,ptobj,verb):
  self.domain=domain; self.noun=enobj; self.nounpt=ptobj
  self.v,self.pp,self.ing,self.vpt=VERBS[verb]
  self.base=f'{self.v} {self.noun}'
  self.past=f'{self.pp} {self.noun}'
  self.gerund=f'{self.ing} {self.noun}'
  self.pt=f'{self.vpt} {self.nounpt}'
  self.context=domain

SCENES=[]
for domain, english, raw, verb_names in DOMAIN_SEEDS:
 for entry in raw.split(';'):
  en,pt=[x.strip() for x in entry.split('|',1)]
  for verb in verb_names: SCENES.append(Scene(domain,en,pt,verb))
assert len(SCENES)==1536,len(SCENES)

# Portuguese sentence starts can capitalize the infinitive phrase safely; to keep
# translations natural we mostly use first-person plural clauses + explicit action.
def scenario(scene,index):
  time,tpt=TIME[(index*7+len(scene.noun))%len(TIME)]
  cause,cpt=CAUSE[(index*11+len(scene.noun)*3)%len(CAUSE)]
  past,ppt=PAST[(index*13+len(scene.v))%len(PAST)]
  consequence,conpt=CONSEQUENCE[(index*17+len(scene.noun))%len(CONSEQUENCE)]
  return dict(a=scene.base,pp=scene.past,ing=scene.gerund,pt=scene.pt,obj=scene.noun,objpt=scene.nounpt,v=scene.v,vpp=scene.pp,ving=scene.ing,vpt=scene.vpt,tm=time,tmpt=tpt,cause=cause,cpt=cpt,past=past,ppt=ppt,con=consequence,conpt=conpt)

def q(sent,pt,opts,correct,hint,exp,level='B2'):
 return dict(sentence=sent,translation=pt,choices=list(opts),correct=int(correct),hint=hint,explanation=exp,level=level)
def b(sent,pt,hint,exp,level='B2',accepted=None):
 x=dict(sentence=sent,translation=pt,hint=hint,explanation=exp,level=level)
 if accepted:x['accepted']=accepted
 return x

# Translation templates are written for the precisely selected grammar pattern.
def quiz_modals(x,variant):
 d=x
 rules=[
 lambda:q(f"Given that {d['cause']}, we ___ {d['a']} {d['tm']}; it would be wise not to wait.",f"Como {d['cpt']}, deveríamos {d['pt']} {d['tmpt']}; seria prudente não esperar.",['should','would have','could have'],0,'Conselho para o presente: use modal + verbo base.','Should + verbo base expressa recomendação. Would have e could have exigem particípio e remetem ao passado.'),
 lambda:q(f"We ___ have {d['pp']} sooner, especially after {d['past']}; waiting was a mistake.",f"Deveríamos ter conseguido {d['pt']} mais cedo, principalmente depois que {d['ppt']}; esperar foi um erro.",['should','will','can'],0,'Há arrependimento por uma decisão anterior.','Should have + particípio indica uma ação que teria sido recomendável no passado.','C1'),
 lambda:q(f"We ___ {d['a']} {d['tm']}; the written policy makes it mandatory.",f"Precisamos obrigatoriamente {d['pt']} {d['tmpt']}; a política escrita torna isso obrigatório.",['might','must','would'],1,'A política impõe uma obrigação, não uma possibilidade.','Must + verbo base expressa obrigação forte quando há uma regra formal.'),
 lambda:q(f"We ___ {d['a']} later if new information comes in, but no decision has been made.",f"Talvez venhamos a {d['pt']} mais tarde se chegarem novas informações, mas nenhuma decisão foi tomada.",['must','might','had to'],1,'A possibilidade ainda está aberta; não há decisão.','Might + verbo base expressa possibilidade sem compromisso com a ação.'),
 lambda:q(f"We ___ {d['a']} so early; everyone agreed there was time to wait.",f"Não precisávamos {d['pt']} tão cedo; todos concordaram que havia tempo para esperar.",['didn’t need to','must not have','were supposed'],0,'A frase diz que não existia necessidade de fazer isso cedo.','Didn’t need to + verbo base expressa falta de necessidade no passado; é natural no inglês americano.','C1'),
 lambda:q(f"___ you mind {d['ing']} {d['tm']}? I want to make sure nothing gets overlooked.",f"Você se importaria de {d['pt']} {d['tmpt']}? Quero garantir que nada seja esquecido.",['Would','Should','Must'],0,'Esta pergunta educada usa Would you mind + -ing.','Would you mind + gerúndio é uma maneira natural e educada de fazer um pedido.'),
 lambda:q(f"We ___ have {d['pp']} already; the completed checklist is right in front of us.",f"Com certeza já conseguimos {d['pt']}; a lista de verificação concluída está bem à nossa frente.",['cannot','must','will'],1,'O registro concluído é uma evidência forte.','Must have + particípio expressa dedução forte sobre um evento passado.','C1'),
 lambda:q(f"If I were responsible for the decision, I ___ {d['a']} {d['tm']} rather than delay again.",f"Se eu fosse responsável pela decisão, eu {d['pt']} {d['tmpt']} em vez de adiar novamente.",['will','have','would'],2,'A condição é hipotética no presente.','Would + verbo base expressa o resultado hipotético do second conditional.'),
 lambda:q(f"We ___ {d['a']} today, because the policy explicitly says it is optional.",f"Não somos obrigados a {d['pt']} hoje, porque a política diz expressamente que isso é opcional.",['must','don’t have to','mustn’t'],1,'Opcional significa ausência de obrigação, não proibição.','Don’t have to expressa falta de necessidade; mustn’t indica proibição.'),
 lambda:q(f"Had we {d['pp']} earlier, we ___ have avoided a lot of confusion.",f"Se tivéssemos conseguido {d['pt']} antes, teríamos evitado muita confusão.",['would','will','are'],0,'Had we é uma inversão de If we had.','Would have + particípio é resultado hipotético no passado.','C1'),
 lambda:q(f"We ___ {d['a']} until the safety concern is resolved; the policy strictly forbids it.",f"Não podemos {d['pt']} até a preocupação de segurança ser resolvida; a política proíbe isso estritamente.",['might','mustn’t','would'],1,'Trata-se de proibição explícita, não de conselho.','Mustn’t expressa proibição; might seria possibilidade.'),
 lambda:q(f"We ___ {d['a']} yesterday, but {d['past']}.",f"Era para termos conseguido {d['pt']} ontem, mas {d['ppt']}.",['are supposed to','were supposed to','might have'],1,'A expectativa pertence ao passado.','Were supposed to + verbo base descreve um plano ou expectativa passada que não se realizou.'),
 lambda:q(f"Given how quickly the details are changing, I ___ rather {d['a']} now than wait.",f"Como os detalhes mudam tão rapidamente, eu preferiria {d['pt']} agora a esperar.",['would','will','can'],0,'Would rather + verbo base expressa preferência.','Would rather indica uma preferência por uma ação em vez de outra.'),
 lambda:q(f"Everyone has already agreed on the next step, so we ___ as well {d['a']} now.",f"Todos já concordaram com a próxima etapa, então podemos muito bem {d['pt']} agora.",['should','must','might'],2,'A expressão idiomática é might as well.','Might as well + verbo base indica que a ação é a opção razoável na situação.'),
 lambda:q(f"If the choice had been mine, I ___ have {d['pp']} {d['tm']}.",f"Se a escolha tivesse sido minha, eu teria conseguido {d['pt']} {d['tmpt']}.",['would','will','can'],0,'A condição descreve uma realidade passada alternativa.','Would have + particípio expressa resultado hipotético não realizado no passado.','C1'),
 ]
 return rules[variant%len(rules)]()

def quiz_patterns(x,variant):
 d=x
 root=d['v']; ing=d['ving'];to='to '+root
 rules=[
 lambda:q(f"We should avoid ___ {d['obj']} {d['tm']}, particularly because {d['cause']}.",f"Deveríamos evitar {d['pt']} {d['tmpt']}, especialmente porque {d['cpt']}.",[to,ing,root],1,'Avoid é seguido por verbo com -ing.','Avoid + -ing: avoid reviewing, avoid updating e construções equivalentes.'),
 lambda:q(f"I’ve been meaning ___ {d['obj']} {d['tm']}, but other priorities keep coming up.",f"Já faz tempo que estou querendo {d['pt']} {d['tmpt']}, mas outras prioridades continuam surgindo.",[ing,to,root],1,'Meaning, com sentido de intenção, pede to-infinitive.','Have been meaning to + verbo base indica uma intenção pendente.'),
 lambda:q(f"Our colleague suggested ___ {d['obj']} again after {d['past']}.",f"Nosso colega sugeriu {d['pt']} novamente depois que {d['ppt']}.",[ing,to,root],0,'Suggest geralmente é seguido de -ing.','Suggest + -ing: suggested reviewing, não suggested to review.'),
 lambda:q(f"We finally decided ___ {d['obj']} {d['tm']} instead of putting it off.",f"Finalmente decidimos {d['pt']} {d['tmpt']} em vez de adiar.",[root,to,ing],1,'Decide normalmente pede to-infinitive.','Decide to + verbo base expressa decisão de realizar uma ação.'),
 lambda:q(f"They kept ___ {d['obj']} even though {d['cause']}.",f"Eles continuaram a {d['pt']} embora {d['cpt']}.",[to,ing,root],1,'Keep, no sentido de continuar, pede -ing.','Keep + -ing expressa continuidade ou repetição de uma atividade.'),
 lambda:q(f"I can’t help ___ {d['obj']} whenever the team asks for more detail.",f"Não consigo evitar {d['pt']} sempre que a equipe pede mais detalhes.",[ing,to,root],0,'Can’t help + -ing significa não conseguir evitar.','Can’t help + -ing é a construção idiomática para algo que não conseguimos evitar.'),
 lambda:q(f"We postponed ___ {d['obj']} until everyone could join the discussion.",f"Adiamos {d['pt']} até que todos pudessem participar da discussão.",[to,root,ing],2,'Postpone pede verbo em -ing.','Postpone + -ing é o padrão para adiar uma ação.'),
 lambda:q(f"I’m looking forward to ___ {d['obj']} when the circumstances are better.",f"Estou ansioso para {d['pt']} quando as circunstâncias melhorarem.",[to,ing,root],1,'O to de look forward to é uma preposição.','Look forward to + -ing é obrigatório para introduzir uma ação.'),
 lambda:q(f"Everyone agreed ___ {d['obj']} {d['tm']} rather than leave the issue unresolved.",f"Todos concordaram em {d['pt']} {d['tmpt']} em vez de deixar a questão sem solução.",[ing,root,to],2,'Agree pede to-infinitive para uma ação.','Agree to + verbo base indica concordar em fazer algo.'),
 lambda:q(f"She admitted ___ {d['obj']} too late to influence the outcome.",f"Ela admitiu ter conseguido {d['pt']} tarde demais para influenciar o resultado.",[to,ing,root],1,'Admit normalmente pede verbo com -ing.','Admit + -ing indica reconhecer que se realizou determinada ação.'),
 lambda:q(f"We considered ___ {d['obj']} after {d['past']}.",f"Consideramos {d['pt']} depois que {d['ppt']}.",[ing,to,root],0,'Consider pede -ing quando seguido de verbo.','Consider + -ing é a construção usada para ponderar uma ação.'),
 lambda:q(f"The coordinator promised ___ {d['obj']} {d['tm']} and keep everyone informed.",f"O coordenador prometeu {d['pt']} {d['tmpt']} e manter todos informados.",[ing,root,to],2,'Promise normalmente pede to-infinitive.','Promise to + verbo base indica compromisso de realizar algo.'),
 lambda:q(f"They managed ___ {d['obj']} despite the unexpected changes.",f"Eles conseguiram {d['pt']} apesar das mudanças inesperadas.",[to,ing,root],0,'Manage com sentido de conseguir pede to.','Manage to + verbo base indica sucesso apesar de uma dificuldade.'),
 lambda:q(f"Would you mind ___ {d['obj']} before the next discussion starts?",f"Você se importaria de {d['pt']} antes de começar a próxima discussão?",[root,to,ing],2,'Would you mind é seguido de -ing.','Would you mind + -ing é um pedido educado.'),
 lambda:q(f"We need ___ {d['obj']} soon because {d['cause']}.",f"Precisamos {d['pt']} logo porque {d['cpt']}.",[ing,to,root],1,'Need + to-infinitive para expressar necessidade da pessoa.','We need to + verbo base, não we need doing.'),
 lambda:q(f"I don’t recall ___ {d['obj']} after the schedule changed.",f"Não me lembro de ter conseguido {d['pt']} depois que o cronograma mudou.",[to,root,ing],2,'Recall costuma pedir -ing para ações lembradas.','Recall + -ing significa recordar-se de ter feito algo.','C1'),
 ]
 return rules[variant%len(rules)]()

# Conditional grammar choices include complete predicate chunks where necessary.
def quiz_conditionals(x,variant):
 d=x
 rules=[
 lambda:q(f"If we receive confirmation today, we ___ {d['a']} {d['tm']}.",f"Se recebermos a confirmação hoje, vamos {d['pt']} {d['tmpt']}.",['would have','will','had'],1,'First conditional: if + presente, will + verbo base.','Will + verbo base expressa consequência provável de uma condição futura.'),
 lambda:q(f"If we had {d['pp']} earlier, we ___ have avoided the confusion.",f"Se tivéssemos conseguido {d['pt']} antes, teríamos evitado a confusão.",['would','will','are'],0,'Third conditional trata de um passado que não aconteceu.','If + past perfect, would have + particípio forma o third conditional.','C1'),
 lambda:q(f"If I were managing the process, I ___ {d['a']} {d['tm']}.",f"Se eu estivesse gerenciando o processo, eu {d['pt']} {d['tmpt']}.",['will','would','had'],1,'Segunda condicional: hipótese irreal no presente.','If + past simple, would + verbo base descreve resultado hipotético.'),
 lambda:q(f"Had we realized that {d['cause']}, we ___ have {d['pp']} much sooner.",f"Se tivéssemos percebido que {d['cpt']}, teríamos conseguido {d['pt']} muito antes.",['would','will','can'],0,'Had we é equivalente a If we had.','Inversão em condição passada seguida de would have + particípio.','C1'),
 lambda:q(f"If we ___ {d['obj']} earlier, the team would have avoided another delay.",f"Se tivéssemos {d['pt']} antes, a equipe teria evitado outro atraso.",[f'had {d["vpp"]}',f'have {d["vpp"]}',f'will {d["v"]}'],0,'A consequência would have indica uma hipótese passada.','Third conditional exige past perfect: had + past participle.'),
 lambda:q(f"Unless we ___ {d['obj']} in time, the team won’t be able to move forward.",f"A menos que consigamos {d['pt']} a tempo, a equipe não poderá avançar.",[d['v'],f'would {d["v"]}',f'had {d["vpp"]}'],0,'Unless introduz uma condição real no presente/futuro.','Depois de unless, usamos present simple para condições futuras.'),
 lambda:q(f"If we ___ {d['obj']} now, we would avoid unnecessary back-and-forth.",f"Se {d['pt']} agora, evitaríamos trocas desnecessárias de mensagens.",[d['vpp'],d['v'],f'have {d["vpp"]}'],0,'Would na consequência pede past simple na hipótese.','Second conditional usa passado simples no if-clause (reviewed, checked, etc.).'),
 lambda:q(f"If the situation had been clearer, we ___ to {d['a']} at the last minute.",f"Se a situação tivesse sido mais clara, não teríamos precisado {d['pt']} na última hora.",["wouldn’t have had", "won’t have", "don't have"],0,'Resultado passado não realizado: would not have had to.','Wouldn’t have had to + verbo base indica necessidade hipotética que teria sido evitada.','C1'),
 lambda:q(f"If I had known about the change, I ___ to {d['a']} before the deadline.",f"Se eu soubesse da mudança, teria tentado {d['pt']} antes do prazo final.",['would have tried','will try','am trying'],0,'O conhecimento ausente pertence ao passado.','Would have tried to + infinitive mostra uma tentativa hipotética não realizada.','C1'),
 lambda:q(f"If you regularly ___ {d['obj']}, you notice inconsistencies earlier.",f"Se você {d['pt']} regularmente, percebe inconsistências mais cedo.",[d['v'],d['vpp'],f'would {d["v"]}'],0,'A frase descreve uma regra habitual.','Zero conditional usa present simple em ambas as orações.'),
 lambda:q(f"Should we ___ {d['obj']} today, we would still have time to make changes.",f"Se conseguíssemos {d['pt']} hoje, ainda teríamos tempo de fazer mudanças.",[d['v'],f'to {d["v"]}',d['vpp']],0,'Should we + verbo base equivale a If we should.','Should + subject + base verb é uma condicional invertida formal.','C1'),
 lambda:q(f"If it weren't for the uncertainty, we ___ be able to {d['a']} this week.",f"Se não fosse pela incerteza, conseguiríamos {d['pt']} nesta semana.",['will','had','would'],2,'If it weren’t for apresenta hipótese irreal.','Would be able to expressa capacidade numa realidade hipotética.'),
 lambda:q(f"Even if we ___ {d['obj']} tomorrow, we might still face some delays.",f"Mesmo que consigamos {d['pt']} amanhã, ainda poderemos enfrentar alguns atrasos.",[d['v'],f'would {d["v"]}',f'had {d["vpp"]}'],0,'Condição futura possível usa present simple após even if.','Even if + present simple permite apresentar uma concessão futura.'),
 lambda:q(f"If we had already {d['pp']}, there ___ no reason to start from scratch now.",f"Se já tivéssemos conseguido {d['pt']}, não haveria motivo para começar do zero agora.",["would have been","would be","will be"],1,'Causa no passado e consequência no presente.','Mixed conditional combina past perfect na condição com would + base verb no resultado presente.','C1'),
 lambda:q(f"If it turns out that {d['cause']}, we ___ to {d['a']} again.",f"Se descobrirmos que {d['cpt']}, teremos que {d['pt']} novamente.",['would have','will have','had'],1,'A consequência é futura e possível.','Will have to + verbo base indica obrigação futura condicionada ao presente.'),
 ]
 return rules[variant%len(rules)]()

PREP_RULES=[
 ('responsible','for','Ser responsável por', 'responsible for + -ing','Our team is responsible ___ {ing} {tm}, so nobody else can take it over.','Nossa equipe é responsável por {pt} {tmpt}, então ninguém mais pode assumir a tarefa.', ['for','of','at'],0),
 ('rely','on','Contar com', 'rely on','We cannot rely ___ {obj} alone when making such an important decision.','Não podemos depender apenas de {objpt} ao tomar uma decisão tão importante.', ['with','on','at'],1),
 ('interested','in','Ter interesse em','interested in + -ing','I am genuinely interested ___ {ing} more carefully this time.','Tenho verdadeiro interesse em {pt} com mais cuidado desta vez.', ['about','to','in'],2),
 ('insisted','on','Insistir em','insist on + -ing','The manager insisted ___ {ing} before anything was approved.','O gerente insistiu em {pt} antes de qualquer aprovação.', ['on','for','to'],0),
 ('apologized','for','Pedir desculpas por','apologize for + -ing','She apologized ___ {ing} after the deadline had already passed.','Ela pediu desculpas por {pt} depois que o prazo já havia passado.', ['to','with','for'],2),
 ('looking','to','Aguardar com expectativa','look forward to + -ing','I am looking forward ___ {ing} when everyone is available.','Estou ansioso para {pt} quando todos estiverem disponíveis.', ['for','at','to'],2),
 ('succeeded','in','Ter sucesso em','succeed in + -ing','They succeeded ___ {ing} despite the unexpected complications.','Eles tiveram sucesso em {pt} apesar das complicações inesperadas.', ['in','at','on'],0),
 ('attention','to','Prestar atenção a','pay attention to','Please pay closer attention ___ {obj} during the next conversation.','Por favor, preste mais atenção em {objpt} durante a próxima conversa.', ['for','to','with'],1),
 ('deal','with','Lidar com','deal with','We need to deal ___ {obj} rather than pretend nothing has changed.','Precisamos lidar com {objpt} em vez de fingir que nada mudou.', ['to','with','for'],1),
 ('familiar','with','Estar familiarizado com','familiar with','Are you familiar ___ {obj}, or should I explain the background?','Você conhece bem {objpt} ou devo explicar o contexto?', ['about','with','in'],1),
 ('charge','of','Estar encarregado de','in charge of + -ing','She is in charge ___ {ing} {tm}.','Ela está encarregada de {pt} {tmpt}.', ['of','on','at'],0),
 ('focused','on','Concentrar-se em','focus on + -ing','The team is focused ___ {ing} instead of arguing about the past.','A equipe está concentrada em {pt} em vez de discutir o passado.', ['in','on','by'],1),
 ('capable','of','Ser capaz de','capable of + -ing','I am confident that the team is capable ___ {ing} without outside help.','Estou confiante de que a equipe é capaz de {pt} sem ajuda externa.', ['of','to','in'],0),
 ('committed','to','Estar comprometido com','committed to + -ing','Everyone is committed ___ {ing}, even if the situation changes.','Todos estão comprometidos em {pt}, mesmo que a situação mude.', ['to','for','in'],0),
 ('accountable','for','Responder por','accountable for + -ing','We are accountable ___ {ing} before the final review.','Somos responsáveis por {pt} antes da revisão final.', ['of','for','at'],1),
 ('depends','on','Depender de','depend on','Our next step depends ___ {obj} being discussed openly first.','Nossa próxima etapa depende de {objpt} ser discutido abertamente antes.', ['at','with','on'],2),
]
def quiz_prepositions(x,variant):
 d=x; tag,correct,pt,ex,template,pttemplate,choices,answer=PREP_RULES[variant%len(PREP_RULES)]
 text=template.format(**d).replace('___','___',1)
 trans=pttemplate.format(**d)
 return q(text,trans,choices,answer,'Reconheça a preposição que acompanha a expressão fixa '+tag+'.',ex+'. Esta combinação não depende de tradução literal.','C1' if variant%5==0 else 'B2')

def quiz_get(x,variant):
 d=x
 rules=[
 lambda:q(f"We finally ___ around to {d['ing']} after {d['past']}.",f"Finalmente conseguimos encontrar tempo para {d['pt']} depois que {d['ppt']}.",['getting','got','get'],1,'Got around to + -ing indica finalmente fazer algo adiado.','Get around to + -ing é a expressão de conseguir fazer algo após um atraso.'),
 lambda:q(f"We are ___ ready to {d['a']} now that the details are clearer.",f"Estamos nos preparando para {d['pt']} agora que os detalhes estão mais claros.",['getting','get','got'],0,'Be + getting + adjective indica mudança progressiva.','Getting ready to + verbo base indica preparação em andamento.'),
 lambda:q(f"I ___ stuck {d['ing']} yesterday because nobody had the latest information.",f"Fiquei preso na tarefa de {d['pt']} ontem porque ninguém tinha as informações mais recentes.",['get','got','getting'],1,'Yesterday pede passado simples.','Got stuck + -ing indica ficar preso ou ter dificuldades realizando uma ação.'),
 lambda:q(f"I have ___ much better at {d['ing']} over the past few months.",f"Melhorei bastante em {d['pt']} nos últimos meses.",['getting','gotten','get'],1,'Após have, use o particípio americano de get.','Have gotten better at + -ing é comum no inglês americano para evolução de habilidade.'),
 lambda:q(f"How did you ___ through {d['ing']} with so little time available?",f"Como você conseguiu superar a tarefa de {d['pt']} com tão pouco tempo disponível?",['got','getting','get'],2,'Did já marca o passado; use a forma base.','Did + subject + get through + -ing descreve superar uma tarefa exigente.'),
 lambda:q(f"We should ___ back to {d['ing']} once everyone has had a chance to respond.",f"Deveríamos voltar a {d['pt']} quando todos tiverem tido a chance de responder.",['get','got','getting'],0,'Após should, use o verbo na forma base.','Get back to + -ing significa retomar uma atividade.'),
 lambda:q(f"We had finally ___ around to {d['ing']} when the plan changed again.",f"Finalmente tínhamos encontrado tempo para {d['pt']} quando o plano mudou de novo.",['get','getting','gotten'],2,'Had pede um particípio passado.','Had gotten around to + -ing indica que uma atividade enfim tinha sido iniciada.','C1'),
 lambda:q(f"I cannot ___ over how much easier {d['ing']} has become lately.",f"Não consigo acreditar em como {d['pt']} ficou muito mais fácil ultimamente.",['got','get','getting'],1,'Depois de cannot, use a forma base.','Get over, neste contexto, significa superar ou deixar de se surpreender com algo.'),
 lambda:q(f"We keep ___ sidetracked while {d['ing']}, especially during busy weeks.",f"Continuamos nos distraindo enquanto tentamos {d['pt']}, especialmente em semanas corridas.",['got','get','getting'],2,'Keep + -ing é a construção de repetição.','Keep getting sidetracked indica que algo nos desvia repetidamente da tarefa.'),
 lambda:q(f"The team ___ carried away with {d['ing']} last time and lost track of the schedule.",f"A equipe se empolgou demais ao {d['pt']} da última vez e perdeu a noção do cronograma.",['getting','gotten','got'],2,'Last time pede passado simples.','Got carried away with + -ing descreve ficar entusiasmado demais com uma atividade.'),
 lambda:q(f"They have ___ used to {d['ing']} even when the pressure is high.",f"Eles se acostumaram a {d['pt']} mesmo sob muita pressão.",['get','getting','gotten'],2,'Have pede particípio passado no inglês americano.','Have gotten used to + -ing expressa uma adaptação concluída ou consolidada.'),
 lambda:q(f"Let’s ___ started with {d['ing']} before the discussion gets too long.",f"Vamos começar a {d['pt']} antes que a discussão fique longa demais.",['getting','get','got'],1,'Let’s + forma base.','Let’s get started with + -ing inicia uma atividade de maneira natural.'),
 lambda:q(f"We ___ caught up in {d['ing']} all afternoon and forgot about the time.",f"Ficamos envolvidos em {d['pt']} durante toda a tarde e perdemos a noção do tempo.",['got','get','getting'],0,'All afternoon descreve uma situação passada encerrada.','Got caught up in + -ing descreve envolvimento intenso numa atividade.'),
 lambda:q(f"I don’t think we will ___ to {d['a']} before the office closes.",f"Acho que não conseguiremos {d['pt']} antes de o escritório fechar.",['getting','got','get'],2,'Will exige a forma base do verbo.','Will get to + verbo base significa ter oportunidade de fazer algo.'),
 lambda:q(f"We are ___ closer to {d['ing']} efficiently every day.",f"Estamos chegando mais perto de conseguir {d['pt']} com eficiência a cada dia.",['get','getting','got'],1,'Be + getting closer to descreve progresso gradual.','Getting closer to + -ing expressa aproximação de uma meta ou habilidade.'),
 lambda:q(f"I never ___ around to {d['ing']} last week, even though it was on my list.",f"Nunca consegui encontrar tempo para {d['pt']} na semana passada, embora estivesse na minha lista.",['get','getting','got'],2,'Last week pede passado simples.','Never got around to + -ing indica uma tarefa adiada que acabou não sendo feita.'),
 ]
 return rules[variant%len(rules)]()

def builder_general(d,k):
 rules=[
 lambda:b(f"We were supposed to {d['a']} {d['tm']}, but {d['cause']}.",f"Era para conseguirmos {d['pt']} {d['tmpt']}, mas {d['cpt']}.",'O plano inicial foi interrompido por uma circunstância.','Were supposed to marca uma expectativa passada; but apresenta a complicação.'),
 lambda:b(f"The sooner we {d['a']}, the easier it will be to avoid last-minute surprises.",f"Quanto mais cedo conseguirmos {d['pt']}, mais fácil será evitar surpresas de última hora.",'Use the sooner..., the easier... para mostrar proporcionalidade.','The + comparative, the + comparative descreve como duas condições variam juntas.','C1'),
 lambda:b(f"I wish we had {d['pp']} before things became more complicated.",f"Gostaria que tivéssemos conseguido {d['pt']} antes de as coisas ficarem mais complicadas.",'I wish + past perfect indica arrependimento.','I wish + had + participle descreve arrependimento por uma ação passada.','C1'),
 lambda:b(f"No matter how busy things get, we still need to {d['a']}.",f"Por mais que as coisas fiquem corridas, ainda precisamos {d['pt']}.",'No matter how inicia uma concessão.','No matter how + adjective expressa que a decisão independe das circunstâncias.'),
 lambda:b(f"I would rather {d['a']} today than leave everyone guessing until tomorrow.",f"Prefiro {d['pt']} hoje a deixar todos sem saber o que acontecerá até amanhã.",'A preferência envolve would rather ... than ...','Would rather + verbo base e than expressam preferência entre ações.'),
 lambda:b(f"We might have to {d['a']} again if the next update changes the picture.",f"Talvez tenhamos que {d['pt']} novamente se a próxima atualização mudar a situação.",'Combine might have to e uma condição futura.','Might have to expressa uma obrigação possível; if + present simple descreve a condição.'),
 lambda:b(f"Instead of waiting for another reminder, let's {d['a']} {d['tm']}.",f"Em vez de esperar outro lembrete, vamos {d['pt']} {d['tmpt']}.",'Instead of pede a forma com -ing.','Instead of + -ing contrasta uma opção evitada com outra recomendada.'),
 lambda:b(f"Had we known what was coming, we would have {d['pp']} much sooner.",f"Se soubéssemos o que viria, teríamos conseguido {d['pt']} muito mais cedo.",'Had we known é uma inversão condicional formal.','O third conditional pode omitir if por inversão: Had we known..., we would have...','C1'),
 lambda:b(f"By the time the next discussion starts, we should have {d['pp']}.",f"Até o início da próxima discussão, já deveríamos ter conseguido {d['pt']}.",'Should have + particípio expressa expectativa de conclusão.','By the time introduz o prazo até o qual se espera que algo esteja concluído.','C1'),
 lambda:b(f"What worries me most is that we might forget to {d['a']}.",f"O que mais me preocupa é que talvez esqueçamos de {d['pt']}.",'Comece com uma oração que funciona como sujeito.','What worries me most funciona como sujeito de uma estrutura complexa.','C1'),
 lambda:b(f"It doesn't make sense to postpone {d['ing']} when everyone needs an answer.",f"Não faz sentido adiar {d['pt']} quando todos precisam de uma resposta.",'Postpone é seguido de -ing.','It doesn’t make sense to + verb expressa que uma decisão parece ilógica.'),
 lambda:b(f"Whether or not the timetable changes, we still need to {d['a']}.",f"Independentemente de o cronograma mudar ou não, ainda precisamos {d['pt']}.",'Whether or not apresenta duas possibilidades.','Whether or not introduz uma concessão independente do resultado.','C1'),
 lambda:b(f"There is no point in {d['ing']} without checking that everyone agrees.",f"Não adianta {d['pt']} sem conferir se todos concordam.",'There is no point in pede -ing.','There is no point in + -ing significa que uma ação não vale a pena nessas condições.'),
 lambda:b(f"We could save ourselves a lot of trouble by {d['ing']} {d['tm']}.",f"Poderíamos evitar muita dor de cabeça se conseguíssemos {d['pt']} {d['tmpt']}.",'By + -ing indica o meio utilizado.','Could + base verb expressa possibilidade; by + -ing descreve como alcançar o resultado.'),
 lambda:b(f"I hadn't realized how much effort it would take to {d['a']} properly.",f"Eu não tinha percebido quanto esforço seria necessário para {d['pt']} adequadamente.",'Hadn’t realized coloca o entendimento num ponto passado.','Past perfect + embedded how much clause expressa uma percepção que ainda não havia ocorrido.','C1'),
 lambda:b(f"Not everyone agrees with the decision to {d['a']} on such short notice.",f"Nem todos concordam com a decisão de {d['pt']} com tão pouca antecedência.",'Not everyone tem escopo parcial: nem todos.','Not everyone agrees expressa discordância parcial, e on short notice indica pouco aviso.'),
 lambda:b(f"As far as I'm concerned, we should {d['a']} before the next update.",f"Na minha opinião, deveríamos {d['pt']} antes da próxima atualização.",'As far as I’m concerned introduz opinião pessoal.','As far as I’m concerned é uma forma idiomática de expressar uma perspectiva.'),
 lambda:b(f"It took a lot of coordination to {d['a']}, but the result was worth it.",f"Foi necessária muita coordenação para {d['pt']}, mas o resultado valeu a pena.",'It took + noun + to-infinitive descreve esforço necessário.','It took a lot of... to... expressa o esforço exigido por uma tarefa.'),
 lambda:b(f"Even though {d['cause']}, we cannot afford to postpone {d['ing']}.",f"Mesmo que {d['cpt']}, não podemos nos dar ao luxo de adiar {d['pt']}.",'Even though introduz contraste com uma dificuldade.','Cannot afford to + verbo base pode expressar que um atraso seria arriscado.','C1'),
 lambda:b(f"The last thing I want is to {d['a']} without understanding the consequences.",f"A última coisa que quero é {d['pt']} sem entender as consequências.",'The last thing I want is to + verb apresenta preferência negativa.','The last thing I want é uma estrutura enfática e natural de intenção.'),
 ]
 return rules[k%len(rules)]()

def builder_perfect(d,k):
 rules=[
 lambda:b(f"I've been meaning to {d['a']} for weeks, but {d['cause']}.",f"Estou querendo {d['pt']} há semanas, mas {d['cpt']}.",'Have been meaning to indica intenção duradoura.','Present Perfect Continuous descreve uma intenção que surgiu no passado e continua agora.'),
 lambda:b(f"We have already {d['pp']}, although the outcome still needs to be checked.",f"Já conseguimos {d['pt']}, embora o resultado ainda precise ser conferido.",'Already vem entre have e o particípio.','Have + already + past participle é a ordem natural da afirmação.'),
 lambda:b(f"Have you ever had to {d['a']} with almost no time to prepare?",f"Você já teve que {d['pt']} quase sem tempo para se preparar?",'Have you ever had to é usado para experiências anteriores.','Have + subject + ever + past participle pergunta sobre experiências até agora.'),
 lambda:b(f"I haven't had a chance to {d['a']} yet because {d['cause']}.",f"Ainda não tive a oportunidade de {d['pt']} porque {d['cpt']}.",'Yet costuma aparecer no fim de uma oração negativa.','Present Perfect com not...yet marca uma ação ainda não realizada.'),
 lambda:b(f"We have been trying to {d['a']} since the last change was announced.",f"Estamos tentando {d['pt']} desde que a última mudança foi anunciada.",'Since apresenta o início de uma ação ainda em andamento.','Have been trying to mostra continuidade e esforço desde um ponto do passado.'),
 lambda:b(f"She has just finished {d['ing']}, which should make tomorrow easier.",f"Ela acabou de concluir a tarefa de {d['pt']}, o que deve facilitar amanhã.",'Just vem entre has e o particípio finished.','Has just + past participle indica conclusão muito recente.'),
 lambda:b(f"This is the first time we've had to {d['a']} under such pressure.",f"Esta é a primeira vez que precisamos {d['pt']} sob tanta pressão.",'This is the first time costuma pedir Present Perfect.','This is the first time + have/has + participle descreve uma experiência inédita.'),
 lambda:b(f"I have never felt completely comfortable {d['ing']} without any context.",f"Nunca me senti totalmente à vontade para {d['pt']} sem nenhum contexto.",'Never vem entre have e o particípio.','Have never + past participle indica ausência de uma experiência até o presente.'),
 lambda:b(f"We haven't stopped {d['ing']} even though the deadline keeps moving.",f"Não paramos de {d['pt']} embora o prazo continue mudando.",'Have not stopped + -ing descreve continuidade.','Present Perfect com stopped + -ing destaca uma atividade que não foi interrompida.'),
 lambda:b(f"How long have you been {d['ing']} without getting a clear response?",f"Há quanto tempo você está {d['pt']} sem receber uma resposta clara?",'How long + have you been + -ing pergunta duração.','Present Perfect Continuous liga o início de uma ação passada ao momento atual.'),
 lambda:b(f"The team has finally managed to {d['a']} after several setbacks.",f"A equipe finalmente conseguiu {d['pt']} depois de vários contratempos.",'Finally aparece entre has e o particípio managed.','Has finally managed to expressa um resultado alcançado após dificuldade.'),
 lambda:b(f"I've rarely seen people so focused on {d['ing']} under pressure.",f"Raramente vi pessoas tão concentradas em {d['pt']} sob pressão.",'Rarely fica entre have e seen.','Have rarely + past participle indica experiência pouco frequente.','C1'),
 lambda:b(f"So far, we haven't been able to {d['a']} without additional help.",f"Até agora, não conseguimos {d['pt']} sem ajuda adicional.",'So far sinaliza o período até o presente.','Have not been able to é uma construção de capacidade no Present Perfect.'),
 lambda:b(f"She has been thinking about {d['ing']} ever since the last meeting.",f"Ela vem pensando em {d['pt']} desde a última reunião.",'Ever since indica a continuidade desde um evento passado.','Has been thinking about + -ing expressa consideração prolongada.'),
 lambda:b(f"We have repeatedly tried to {d['a']}, but the timing hasn't worked out.",f"Tentamos repetidamente {d['pt']}, mas o momento ainda não foi adequado.",'Repeatedly vem entre have e o particípio tried.','Have repeatedly tried destaca diversas tentativas até o momento presente.'),
 lambda:b(f"We've just been told to {d['a']} before the end of the week.",f"Acabaram de nos orientar a {d['pt']} antes do fim da semana.",'Have just been told forma um Present Perfect passivo.','Have + just + been + past participle é a ordem comum em voz passiva.','C1'),
 lambda:b(f"I haven't fully understood why we need to {d['a']} again.",f"Ainda não entendi completamente por que precisamos {d['pt']} novamente.",'Fully vem entre haven’t e understood.','Have not + adverb + past participle é ordem natural para modificar a conclusão.'),
 lambda:b(f"We have been considering {d['ing']} ever since {d['past']}.",f"Estamos considerando {d['pt']} desde que {d['ppt']}.",'Have been considering destaca processo contínuo de decisão.','Present Perfect Continuous + since indica uma consideração que começou no passado.','C1'),
 lambda:b(f"Neither of us has had enough time to {d['a']} properly yet.",f"Nenhum de nós teve tempo suficiente para {d['pt']} adequadamente até agora.",'Neither of us é gramaticalmente singular.','Neither of us has had usa auxiliar singular e Present Perfect.','C1'),
 lambda:b(f"I have only recently started {d['ing']}, so I'm still learning the process.",f"Só recentemente comecei a {d['pt']}, por isso ainda estou aprendendo o processo.",'Only recently indica mudança recente.','Have only recently started destaca início relativamente recente de uma atividade.'),
 ]
 return rules[k%len(rules)]()

def builder_order(d,k):
 rules=[
 lambda:b(f"We had already been asked to {d['a']} before the latest update arrived.",f"Já tinham nos pedido para {d['pt']} antes de chegar a atualização mais recente.",'No Past Perfect Passive, already vem após had.','Had + already + been + past participle é a ordem convencional da estrutura passiva.','C1'),
 lambda:b(f"I will probably need to {d['a']} before the team can move on.",f"Provavelmente vou precisar {d['pt']} antes que a equipe possa avançar.",'Probably vem entre will e need.','Will + probably + main verb é uma ordem comum com advérbio de probabilidade.',accepted=[f"I probably will need to {d['a']} before the team can move on."]),
 lambda:b(f"Could you tell me when we should {d['a']} without delaying anything else?",f"Você poderia me dizer quando deveríamos {d['pt']} sem atrasar mais nada?",'Perguntas indiretas têm a ordem de afirmação.','Depois de when em pergunta indireta, usamos sujeito + auxiliar, sem inversão.'),
 lambda:b(f"Rarely do we get enough time to {d['a']} as carefully as we'd like.",f"Raramente temos tempo suficiente para {d['pt']} com tanto cuidado quanto gostaríamos.",'Rarely no início exige inversão com do.','Advérbios negativos/restritivos iniciais podem exigir auxiliar antes do sujeito.','C1'),
 lambda:b(f"Only after the meeting ended did we realize we needed to {d['a']}.",f"Só depois que a reunião terminou percebemos que precisávamos {d['pt']}.",'Only after no começo exige inversão na oração principal.','Only after + clause + did + sujeito + verbo é uma inversão enfática.','C1'),
 lambda:b(f"Not only did she {d['a']}, but she also explained why it mattered.",f"Ela não apenas conseguiu {d['pt']}, como também explicou por que isso importava.",'Not only no começo exige inversão com did.','Not only did + subject + base verb destaca duas contribuições relacionadas.','C1'),
 lambda:b(f"What exactly did they say about {d['obj']} during the last call?",f"O que exatamente disseram sobre {d['objpt']} durante a última ligação?",'Pergunta direta exige did antes do sujeito.','What + adverb + did + subject + base verb é ordem de pergunta direta.'),
 lambda:b(f"I have hardly ever seen anyone {d['a']} so calmly under pressure.",f"Quase nunca vi alguém {d['pt']} com tanta calma sob pressão.",'Hardly ever vem após have e antes de seen.','Have + hardly ever + past participle posiciona o advérbio entre auxiliar e verbo.','C1'),
 lambda:b(f"We should probably not {d['a']} until the information is complete.",f"Provavelmente não deveríamos {d['pt']} até que as informações estejam completas.",'Probably e not podem ocorrer após should.','Modal + probably + not + base verb apresenta avaliação cautelosa.','C1'),
 lambda:b(f"Hardly had we started to {d['a']} when the plan changed again.",f"Mal tínhamos começado a {d['pt']} quando o plano mudou de novo.",'Hardly na abertura exige inversão com had.','Hardly had + subject + participle ... when ... é inversão temporal formal.','C1'),
 lambda:b(f"She may still be trying to {d['a']} when we get there.",f"Talvez ela ainda esteja tentando {d['pt']} quando chegarmos lá.",'Still geralmente vem após modal e antes de be.','Modal + still + be + -ing é uma sequência natural para possibilidade contínua.'),
 lambda:b(f"Never before have we had to {d['a']} under such tight deadlines.",f"Nunca antes tivemos que {d['pt']} sob prazos tão apertados.",'Never before no começo exige inversão.','Never before + have + subject + past participle cria ênfase.','C1'),
 lambda:b(f"Only then did the team decide to {d['a']} properly.",f"Só então a equipe decidiu {d['pt']} de forma adequada.",'Only then provoca inversão com did.','Only then did + subject + base verb é uma ordem enfática comum.','C1'),
 lambda:b(f"It's important to know whether we can still {d['a']} in time.",f"É importante saber se ainda conseguimos {d['pt']} a tempo.",'Whether introduz oração indireta sem inversão.','Whether + subject + modal + verb usa a ordem de afirmação.'),
 lambda:b(f"I had completely forgotten that we were supposed to {d['a']} today.",f"Eu tinha esquecido completamente que era para {d['pt']} hoje.",'Completely pode ficar entre had e forgotten.','Had + completely + past participle é uma ordem natural no Past Perfect.'),
 lambda:b(f"By tomorrow morning, we will most likely have to {d['a']} once again.",f"Até amanhã de manhã, muito provavelmente teremos que {d['pt']} novamente.",'Most likely aparece entre will e have to.','Will + most likely + have to é uma ordem natural para estimar necessidade futura.'),
 lambda:b(f"I would definitely rather {d['a']} now than deal with the consequences later.",f"Eu definitivamente preferiria {d['pt']} agora a lidar com as consequências depois.",'Definitely vem após would e antes de rather.','Would + adverb + rather + base verb expressa preferência com ênfase.'),
 lambda:b(f"What we really need to do first is {d['a']} before moving on.",f"O que realmente precisamos fazer primeiro é {d['pt']} antes de avançar.",'What we really need é uma oração substantiva.','What-clause + be + bare infinitive pode enfatizar a ação necessária.','C1'),
 lambda:b(f"No sooner had we agreed to {d['a']} than the schedule changed.",f"Mal tínhamos concordado em {d['pt']} e o cronograma já mudou.",'No sooner no início exige inversão com had.','No sooner had + subject + participle ... than ... é uma inversão temporal formal.','C1'),
 lambda:b(f"Seldom have I been asked to {d['a']} with so little preparation.",f"Raramente me pediram para {d['pt']} com tão pouca preparação.",'Seldom no início exige inversão com have.','Seldom + auxiliary + subject + past participle é uma inversão enfática.','C1'),
 ]
 return rules[k%len(rules)]()

def builder_phrasals(d,k):
 rules=[
 lambda:b(f"We need to go over {d['obj']} one more time before the deadline.",f"Precisamos revisar {d['objpt']} mais uma vez antes do prazo final.",'Go over significa revisar ou examinar.','Go over + object é o phrasal verb usado para revisar detalhes.'),
 lambda:b(f"I finally managed to sort out {d['obj']} after a confusing conversation.",f"Finalmente consegui resolver a questão de {d['objpt']} depois de uma conversa confusa.",'Sort out significa resolver ou organizar.','Sort out + object é separável quando há pronome e significa resolver uma questão.'),
 lambda:b(f"Could you bring up {d['obj']} during our next conversation?",f"Você poderia mencionar {d['objpt']} durante nossa próxima conversa?",'Bring up significa levantar ou mencionar um assunto.','Bring up + noun introduz um tópico para discussão.'),
 lambda:b(f"We put off {d['ing']} because the timing did not feel right.",f"Adiamos {d['pt']} porque o momento não parecia adequado.",'Put off + -ing significa adiar uma atividade.','Put off + -ing é uma construção natural quando adiamos uma ação.'),
 lambda:b(f"She looked into {d['obj']} and found several details we had missed.",f"Ela investigou {d['objpt']} e encontrou vários detalhes que não tínhamos percebido.",'Look into significa investigar.','Look into + object descreve examinar uma questão com mais atenção.'),
 lambda:b(f"I cannot figure out how to {d['a']} without causing unnecessary delays.",f"Não consigo descobrir como {d['pt']} sem provocar atrasos desnecessários.",'Figure out how to significa descobrir como fazer algo.','Figure out + embedded clause é uma expressão natural de resolução de problemas.'),
 lambda:b(f"They came up with a better way to {d['a']} after the last setback.",f"Eles encontraram uma forma melhor de {d['pt']} depois do último contratempo.",'Come up with significa criar/encontrar uma ideia.','Came up with + noun introduz a solução concebida.'),
 lambda:b(f"We ended up {d['ing']} even though it was not part of the plan.",f"Acabamos {d['pt']} embora isso não estivesse no plano.",'End up + -ing descreve resultado final.','End up + -ing introduz uma ação que acabou acontecendo.'),
 lambda:b(f"We should follow up on {d['obj']} before the next round of decisions.",f"Deveríamos acompanhar {d['objpt']} antes da próxima rodada de decisões.",'Follow up on significa acompanhar ou cobrar andamento.','Follow up on + noun é uma colocação comum em inglês profissional.'),
 lambda:b(f"I kept trying to get around to {d['ing']} throughout the week.",f"Passei a semana tentando encontrar tempo para {d['pt']}.",'Get around to + -ing significa finalmente conseguir fazer.','Get around to + -ing conecta uma tarefa adiada à oportunidade de realizá-la.'),
 lambda:b(f"The whole team pitched in to {d['a']} before the deadline.",f"Toda a equipe deu uma força para {d['pt']} antes do prazo final.",'Pitch in significa ajudar coletivamente.','Pitch in to + base verb descreve colaborar numa tarefa.'),
 lambda:b(f"I ran into a problem while {d['ing']} earlier this morning.",f"Encontrei um problema enquanto tentava {d['pt']} hoje de manhã.",'Run into significa encontrar inesperadamente.','Run into a problem pode descrever uma dificuldade inesperada durante uma tarefa.'),
 lambda:b(f"She kept putting off {d['ing']} until the task became urgent.",f"Ela continuou adiando {d['pt']} até a tarefa ficar urgente.",'Put off pede -ing quando seguido por uma ação.','Keep putting off + -ing mostra adiamento repetido.'),
 lambda:b(f"We have to work out how to {d['a']} without disrupting anyone's plans.",f"Precisamos descobrir como {d['pt']} sem atrapalhar os planos de ninguém.",'Work out how to significa encontrar uma solução prática.','Work out + how to + base verb expressa resolver uma questão operacional.'),
 lambda:b(f"Let's touch base about {d['obj']} before making the final decision.",f"Vamos conversar rapidamente sobre {d['objpt']} antes de tomar a decisão final.",'Touch base é uma conversa rápida de alinhamento.','Touch base about + noun é uma expressão comum em ambientes de trabalho.'),
 lambda:b(f"The issue came up again while we were {d['ing']} yesterday.",f"A questão surgiu novamente enquanto estávamos ocupados em {d['pt']} ontem.",'Come up descreve assunto que surge.','Come up pode significar aparecer ou ser mencionado inesperadamente.'),
 lambda:b(f"We shouldn't brush off concerns about {d['obj']} just because everyone seems busy.",f"Não deveríamos ignorar preocupações sobre {d['objpt']} só porque todos parecem ocupados.",'Brush off significa desconsiderar.','Brush off concerns indica desprezar preocupações sem analisá-las.','C1'),
 lambda:b(f"We agreed to take care of {d['obj']} before the weekend.",f"Concordamos em cuidar de {d['objpt']} antes do fim de semana.",'Take care of significa cuidar ou resolver.','Take care of + noun descreve assumir e resolver uma responsabilidade.'),
 lambda:b(f"Let's wrap up {d['ing']} before everyone signs off for the day.",f"Vamos terminar de {d['pt']} antes que todos encerrem o expediente.",'Wrap up significa concluir.','Wrap up + -ing descreve terminar uma atividade que está em andamento.'),
 lambda:b(f"We cannot keep putting {d['obj']} off when the deadline is this close.",f"Não podemos continuar adiando {d['objpt']} com o prazo tão próximo.",'O objeto aparece entre put e off.','Put off é separável; put something off é uma ordem natural.','C1'),
 ]
 return rules[k%len(rules)]()

GENS={
 'modals':quiz_modals,'patterns':quiz_patterns,'conditionals':quiz_conditionals,
 'prepositions':quiz_prepositions,'get':quiz_get,
 'build':builder_general,'perfect':builder_perfect,'order':builder_order,'phrasals':builder_phrasals,
}
RULE_COUNTS={'modals':15,'patterns':16,'conditionals':15,'prepositions':16,'get':16,'build':20,'perfect':20,'order':20,'phrasals':20}

def normalized(s):
 s=unicodedata.normalize('NFKC',s).replace('’',"'").lower()
 s=re.sub(r'[^a-z0-9\s]','',s)
 return re.sub(r'\s+',' ',s).strip()

# Vocab notes for phrasal verbs and high-value grammar structures.
GEN_VOCAB={
 'get':'Get pode significar conseguir, ficar ou tornar-se; depende da expressão.',
 'got':'Passado de get; pode integrar phrasal verbs.',
 'gotten':'Particípio de get no inglês americano.',
 'getting':'Forma -ing de get; ficando ou conseguindo.',
 'should':'Deveria (conselho).','might':'Pode ser que / talvez.','rather':'Em would rather, preferiria.',
 'already':'Já; depois do auxiliar e antes do particípio.','hardly':'Quase não; frequentemente faz parte de uma inversão.',
 'seldom':'Raramente; pode exigir inversão.','rarely':'Raramente; pode exigir inversão.',
 'whether':'Se; introduz duas possibilidades.', 'unless':'A menos que.',
 'no':'Não; em no sooner, mal/assim que.', 'sooner':'Mais cedo.',
 'yet':'Ainda; geralmente ao final de negativas e perguntas.',
 'mean':'Em have been meaning to, ter a intenção de.',
 'figure':'Em figure out, descobrir ou entender.',
 'out':'Partícula de expressão verbal; consulte o phrasal verb completo.',
 'over':'Em go over, revisar; em get over, superar.',
 'up':'Partícula de expressão verbal; consulte o phrasal verb completo.',
 'off':'Em put off, adiar; partícula de expressão verbal.',
 'into':'Em look into, investigar.',
 'brought':'Passado de bring; em bring up, mencionar.',
 'pitch':'Em pitch in, colaborar.',
 'wrap':'Em wrap up, concluir.',
 'despite':'Apesar de.', 'although':'Embora.',
 'however':'Entretanto.', 'even':'Até / mesmo; depende da construção.',
 'meanwhile':'Enquanto isso.', 'since':'Desde; pode indicar causa.',
 'previous':'Anterior.', 'unexpected':'Inesperado.',
 'eventually':'Por fim; depois de algum tempo.',
 'deadline':'Prazo final.', 'discussion':'Discussão.',
 'misunderstanding':'Mal-entendido.', 'informed':'Bem informado.',
 'priority':'Prioridade.', 'decision':'Decisão.', 'details':'Detalhes.',
 'the':'O / a / os / as.', 'our':'Nosso / nossa.', 'we':'Nós.', 'have':'Ter; também auxiliar do Present Perfect.',
}

COMMON_WORDS=set('the a an our your his her their this that these those we they i you us it he she to for of in with on at by from over into and or but if although when since because under after before above below do did does have has had am is are was were be been being would could should must might will can as how what who why which where while all some any every there here one two no not than then now soon again yesterday today tomorrow everybody everyone someone nobody next earlier later first already ever never just yet still enough little much more most so time plan team people person fact answer work need want trying'.split())
def phrase_vocabulary(scene,sentence, d):
 v={scene.v:scene.vpt.capitalize(),scene.pp:scene.vpt.capitalize()+' (passado/particípio)',scene.ing:scene.vpt.capitalize()+' (forma -ing)'}
 words=set(re.sub(r'[^a-zA-Z\s-]',' ',sentence.lower()).split())
 v.update({key:value for key,value in GEN_VOCAB.items() if key in words})
 def context(en,pt):
  for word in set(re.sub(r'[^a-zA-Z\s-]',' ',en.lower()).split()):
   if word in words and word not in COMMON_WORDS and word not in v and len(word)>=4:
    v[word]=f'Na expressão “{en}”: {pt}.'
 context(scene.noun,scene.nounpt)
 for k,kpt in [('cause','cpt'),('past','ppt'),('tm','tmpt'),('past2','past2pt'),('cause2','cause2pt')]:
  if k in d:context(d[k],d[kpt])
 return v


# Context-rich situational clauses; generated variants are not claimed as
# individually human-reviewed.  The list is used to avoid shallow variations.
CONTEXT_FRAMES=[
 ("Several people have asked about {obj} since {past2}.","Várias pessoas perguntaram sobre {objpt} desde que {past2pt}."),
 ("The situation became more urgent after {past2}.","A situação ficou mais urgente depois que {past2pt}."),
 ("At the moment, {cause2}; that makes the timing important.","Neste momento, {cause2pt}; isso torna o prazo importante."),
 ("The discussion about {obj} changed direction after {past2}.","A discussão sobre {objpt} mudou de rumo depois que {past2pt}."),
 ("Nobody wants another misunderstanding about {obj}.","Ninguém quer outro mal-entendido sobre {objpt}."),
 ("An earlier conversation left us wondering whether to {a}.","Uma conversa anterior nos deixou pensando se deveríamos {pt}."),
 ("We have been under pressure since {past2}.","Estamos sob pressão desde que {past2pt}."),
 ("Someone raised questions about {obj} when {past2}.","Alguém levantou dúvidas sobre {objpt} quando {past2pt}."),
 ("The original request to {a} came before {past2}.","O pedido original de {pt} veio antes que {past2pt}."),
 ("By the time we started talking about {obj}, {past2}.","Quando começamos a conversar sobre {objpt}, {past2pt}."),
 ("There is still a lot of uncertainty, partly because {cause2}.","Ainda há bastante incerteza, em parte porque {cause2pt}."),
 ("The situation is more delicate than it looks because {cause2}.","A situação é mais delicada do que parece porque {cause2pt}."),
 ("We cannot ignore the fact that {cause2}.","Não podemos ignorar o fato de que {cause2pt}."),
 ("The timing became difficult when {past2}.","O momento se tornou complicado quando {past2pt}."),
 ("The details have changed since {past2}.","Os detalhes mudaram desde que {past2pt}."),
 ("Before making a decision, we should remember that {cause2}.","Antes de tomar uma decisão, devemos lembrar que {cause2pt}."),
 ("We have not reached a clear conclusion since {past2}.","Não chegamos a uma conclusão clara desde que {past2pt}."),
 ("The conversation is still unresolved because {cause2}.","A conversa continua sem solução porque {cause2pt}."),
 ("Someone has asked for an update on {obj}.","Alguém pediu uma atualização sobre {objpt}."),
 ("The next discussion will probably focus on {obj}.","A próxima conversa provavelmente terá como foco {objpt}."),
 ("The next steps depend on how {obj} affects the rest of the plan.","As próximas etapas dependem de como {objpt} afeta o restante do plano."),
]

def contextualize(record, d, idx, key):
 story=idx//RULE_COUNTS[key]
 p2,p2pt=PAST[(story//(len(CONTEXT_FRAMES)*len(CAUSE)))%len(PAST)]
 c2,c2pt=CAUSE[(story//len(CONTEXT_FRAMES))%len(CAUSE)]
 d.update({'past2':p2,'past2pt':p2pt,'cause2':c2,'cause2pt':c2pt})
 frame=CONTEXT_FRAMES[story%len(CONTEXT_FRAMES)]
 en,pt=(v.format(**d) for v in frame)
 if (idx//21+ORDER.index(key))%2==0:
  record['sentence']=en+' '+record['sentence']
  record['translation']=pt+' '+record['translation']
  if 'accepted' in record:record['accepted']=[en+' '+alt for alt in record['accepted']]
 else:
  record['sentence']+=' '+en
  record['translation']+=' '+pt
  if 'accepted' in record:record['accepted']=[alt+' '+en for alt in record['accepted']]
 return record

def make_one(key,idx):
 # Use all 1,536 action/context combinations and every grammar pattern in a
 # balanced, deterministic order, not a single repeated phrase with new nouns.
 scene=SCENES[(idx*59 + ORDER.index(key)*173)%len(SCENES)]
 variant=idx%RULE_COUNTS[key]
 d=scenario(scene,idx + ORDER.index(key)*29)
 record=GENS[key](d,variant)
 # A verb- or action-specific follow-up makes individual tasks meaningfully
 # contextualized even when the grammatical gap conceals the main verb.
 if key in ('patterns','prepositions','conditionals','order','phrasals'):
  addenda=[
   ('Our next step is to {a} before making a final decision.','O próximo passo é {pt} antes de tomar uma decisão final.'),
   ('The real challenge is finding enough time to {a} without rushing.','O verdadeiro desafio é encontrar tempo suficiente para {pt} sem pressa.'),
   ('It would help if someone could {a} carefully.','Ajudaria se alguém pudesse {pt} com cuidado.'),
   ('This matters because the team plans to {a} next.','Isso importa porque a equipe planeja {pt} em seguida.'),
   ('People are still debating whether to {a} at all.','As pessoas ainda discutem se deveriam {pt}.'),
   ('The original plan was to {a} earlier this week.','O plano original era {pt} no começo desta semana.'),
   ('If the timing works, we can {a} tomorrow.','Se o momento for adequado, podemos {pt} amanhã.'),
   ('Our goal is to {a} without creating more confusion.','Nossa meta é {pt} sem criar mais confusão.'),
   ('We were specifically asked to {a} before going further.','Pediram especificamente que conseguíssemos {pt} antes de avançar.'),
   ('We cannot delay the decision to {a} indefinitely.','Não podemos adiar indefinidamente a decisão de {pt}.'),
   ('Nobody wants to {a} without agreeing on the details.','Ninguém quer {pt} sem concordar sobre os detalhes.'),
   ('One practical option is to {a} before Friday.','Uma opção prática é {pt} antes de sexta-feira.')]
  addon=addenda[(idx*7+variant*3)%len(addenda)]
  record['sentence']+=' '+addon[0].format(**d)
  if 'accepted' in record:record['accepted']=[alt+' '+addon[0].format(**d) for alt in record['accepted']]
  record['translation']+=' '+addon[1].format(**d)
 contextualize(record,d,idx,key)
 record.update(id=f'{PREFIX[key]}{idx+11}',category=key,context=scene.context,
    batch=f'grammar-{(idx//1500)+1:03d}',origin='rule-generated',
    validation='structural+dedup')
 record['vocab']=phrase_vocabulary(scene,record['sentence'],d)
 return record


def check_valid(key,x,seenids,seenphrases):
 assert x['id'] not in seenids,('duplicate ID',x['id'])
 seenids.add(x['id'])
 assert x['category']==key and x['level'] in ('B2','C1')
 for field in ('context','sentence','translation','hint','explanation'):
  assert isinstance(x[field],str) and len(x[field])>=12,(key,x['id'],field)
 phrase=normalized(x['sentence']);assert phrase not in seenphrases,('duplicate sentence',x['id'])
 seenphrases.add(phrase)
 if key in ORDER[:5]:
  assert x['sentence'].count('___')==1,(key,x['id'],'blank')
  assert len(x['choices'])==3 and isinstance(x['correct'],int) and 0<=x['correct']<3
  assert len(set(map(normalized,x['choices'])))==3,(key,x['id'],'choices')
 else:
  assert len(x['sentence'].split())>=9,(key,x['id'],'too few tokens')
  assert isinstance(x['vocab'],dict)
  for alt in x.get('accepted',[]):
   words=lambda s:sorted(re.sub(r'[^a-zA-Z\-\s]','',s.lower()).split())
   assert words(alt)==words(x['sentence']),(key,x['id'],'accepted')


def build_all():
 seenids=set();seenphrases=set();counts={}
 for key in ORDER:
  out=list(ORIGINAL[key]);
  for i in range(9990):out.append(make_one(key,i))
  assert len(out)==10000,(key,len(out))
  for x in out:check_valid(key,x,seenids,seenphrases)
  target=CONTENT/f'{key}.json'
  target.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
  # Browser preview fallback (Android native loads the JSON directly through the bridge).
  (CONTENT/f'{key}.js').write_text('window.EXERCISE_DATA=window.EXERCISE_DATA||{};window.EXERCISE_DATA['+json.dumps(key)+']='+json.dumps(out,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
  counts[key]=len(out)
  print(key,len(out),round(target.stat().st_size/1e6,2),'MB',flush=True)
 manifest=dict(version='2026-11-22-compositional-90000',targetPerSection=10000,targetTotal=90000,validatedTotal=90000,
    validationScope='automated checks for structure, answer keys and exact duplicates; 89,910 generated records require editorial review',
    fullEditorialReviewComplete=False,originalCuratedTotal=90,generatedRuleBasedTotal=89910,sections=counts)
 (CONTENT/'manifest.js').write_text('window.EXERCISE_MANIFEST='+json.dumps(manifest,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
 print('TOTAL',sum(counts.values()),' unique IDs',len(seenids),'unique phrases',len(seenphrases),flush=True)

if __name__=='__main__':build_all()
