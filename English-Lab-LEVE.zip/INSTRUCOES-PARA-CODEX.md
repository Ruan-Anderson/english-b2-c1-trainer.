# Codex — compile o único projeto final de 90.000 questões

Este ZIP contém **90.000 exercícios reais, 10.000 por seção**. Não substitua o aplicativo por um projeto de demonstração e **não gere um banco fictício no lugar dos arquivos JSON incluídos**.

1. Extraia o ZIP integralmente. Preserve o package e o identificador `com.englishlab.trainer`.
2. Confirme a contagem por categoria com `node tests/validate_content.cjs` e verifique o fluxo com `node tests/flow.cjs` e a estrutura SQLite com `python3 tests/validate_sqlite.py`.
3. Compile um **APK Android instalável**, com JDK 17, Gradle 8.13, SDK 35 e Android Gradle Plugin 8.9.2. Corrija qualquer problema de compilação sem remover exercícios ou funcionalidades.
4. Verifique o APK gerado para confirmar a inclusão dos nove arquivos `content/{secao}.json` de 10.000 exercícios cada. Abra cada seção, avance pelo botão Próximo, teste revisão, traduções, contador, PDF e backup.
5. Caso tenha acesso à chave de assinatura original, reutilize-a e confirme que a versão 3 atualiza a versão anterior sem perda de progresso. Caso não tenha, **não prometa atualização preservando dados sem antes testar o backup/restauração**.
6. Forneça **o APK efetivamente compilado**, resultado dos testes e link acessível pelo celular. O ZIP é código-fonte, não APK.
7. O banco contém 90 exercícios de autoria individual anterior e 89.910 registros compostos programaticamente; testes validam estrutura e unicidade exata, **não revisão editorial humana de cada frase**. Não afirme que isso foi auditado manualmente.
8. Se integrar ao repositório `Ruan-Anderson/english-b2-c1-trainer.` (o ponto é parte do nome), preserve seu README inicial e o histórico Git; não utilize `force push`.
